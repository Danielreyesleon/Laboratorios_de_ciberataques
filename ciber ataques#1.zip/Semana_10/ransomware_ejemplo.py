# ---------------------------------------------------------
# Script: simulación educativa de ransomware
# Curso: CY-302 Programación Avanzada — Semana 10
# ---------------------------------------------------------
# Contexto del laboratorio:
# El ransomware cifra archivos de la víctima y exige un pago
# (rescate) a cambio de la clave de descifrado. En la práctica
# puede destruir o bloquear documentos, fotos y sistemas enteros.
#
# Versión ORIGINAL (INSEGURA / incompleta):
# - Intentaba cifrar "test.txt" en la carpeta actual con Fernet.
# - No limitaba el alcance: un error podría afectar archivos reales.
# - Faltaban imports y las funciones write_key()/load_key().
#
# Objetivo de ESTA versión (segura / educativa):
# - Demostrar el flujo: generar clave -> cifrar -> nota de rescate
#   -> descifrar (recuperación).
# - Trabajar SOLO dentro de una carpeta sandbox creada por el script.
# - Nunca recorrer el disco completo ni tocar archivos del estudiante
#   fuera de esa carpeta.
# - Al final, descifrar automáticamente para dejar el laboratorio limpio.
# - Usar cryptography.Fernet si está disponible; si no, un cifrado
#   educativo con la librería estándar (solo para la demo).
# ---------------------------------------------------------

from __future__ import annotations

import base64
import hashlib
import os
from pathlib import Path

# ---------------------------------------------------------
# 1. Configuración del sandbox (zona segura del laboratorio)
# ---------------------------------------------------------
# SANDBOX_DIR: única carpeta donde se permite cifrar/descifrar.
# KEY_FILE / NOTE_FILE: clave y "nota de rescate" educativas.
# Nunca se usa "C:\", el home del usuario ni rutas absolutas ajenas.
# ---------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
SANDBOX_DIR = BASE_DIR / "ransomware_lab_sandbox"
KEY_FILE = SANDBOX_DIR / "lab_key.key"
NOTE_FILE = SANDBOX_DIR / "LEEAME_RESCATE.txt"

# Archivos de demostración (contenido ficticio)
DEMO_FILES = {
    "documento_trabajo.txt": (
        "Informe de laboratorio CY-302\n"
        "Este es un documento de prueba dentro del sandbox.\n"
        "No contiene datos reales del estudiante.\n"
    ),
    "notas_clase.txt": (
        "Notas ficticias:\n"
        "- Hashing SHA-256\n"
        "- Simulación de bot/C2\n"
        "- Keylogger educativo\n"
        "- Ransomware educativo\n"
    ),
    "lista_tareas.txt": (
        "1. Revisar boot.py\n"
        "2. Revisar keylogger_ejemplo.py\n"
        "3. Revisar ransomware_ejemplo.py\n"
    ),
}


# ---------------------------------------------------------
# 2. Motor de cifrado (Fernet o fallback educativo)
# ---------------------------------------------------------
# Fernet (cryptography): cifrado simétrico real, típico en demos.
# Fallback: XOR + Base64 con clave derivada de SHA-256.
#   NO es criptografía de producción; solo permite ejecutar la
#   práctica si no está instalado el paquete cryptography.
# ---------------------------------------------------------

try:
    from cryptography.fernet import Fernet

    HAS_FERNET = True
except ImportError:
    HAS_FERNET = False


class LabCipher:
    """Cifrador del laboratorio: Fernet o fallback educativo."""

    def __init__(self, key: bytes) -> None:
        self.key = key
        if HAS_FERNET:
            self._fernet = Fernet(key)
        else:
            self._fernet = None

    @staticmethod
    def generate_key() -> bytes:
        if HAS_FERNET:
            return Fernet.generate_key()
        # Clave educativa de 32 bytes en Base64 (formato similar a Fernet)
        raw = os.urandom(32)
        return base64.urlsafe_b64encode(raw)

    def encrypt(self, data: bytes) -> bytes:
        if self._fernet is not None:
            return self._fernet.encrypt(data)
        return self._xor_encrypt(data)

    def decrypt(self, data: bytes) -> bytes:
        if self._fernet is not None:
            return self._fernet.decrypt(data)
        return self._xor_decrypt(data)

    def _stream_key(self, length: int) -> bytes:
        # Deriva una secuencia a partir de la clave (solo para el fallback)
        material = hashlib.sha256(self.key).digest()
        out = bytearray()
        counter = 0
        while len(out) < length:
            block = hashlib.sha256(material + counter.to_bytes(4, "big")).digest()
            out.extend(block)
            counter += 1
        return bytes(out[:length])

    def _xor_encrypt(self, data: bytes) -> bytes:
        stream = self._stream_key(len(data))
        xored = bytes(a ^ b for a, b in zip(data, stream))
        return base64.urlsafe_b64encode(xored)

    def _xor_decrypt(self, data: bytes) -> bytes:
        raw = base64.urlsafe_b64decode(data)
        stream = self._stream_key(len(raw))
        return bytes(a ^ b for a, b in zip(raw, stream))


# ---------------------------------------------------------
# 3. Preparación del sandbox
# ---------------------------------------------------------
# Crea la carpeta y los archivos de demo. Si ya existen, los
# regenera en texto plano para empezar la práctica limpia.
# ---------------------------------------------------------

def prepare_sandbox() -> list[Path]:
    """Crea el sandbox y los archivos de demostración."""
    SANDBOX_DIR.mkdir(exist_ok=True)
    created: list[Path] = []
    for name, content in DEMO_FILES.items():
        path = SANDBOX_DIR / name
        path.write_text(content, encoding="utf-8")
        created.append(path)
    return created


def save_key(key: bytes) -> None:
    """Guarda la clave dentro del sandbox (en un ataque real el atacante la retiene)."""
    KEY_FILE.write_bytes(key)


def load_key() -> bytes:
    """Carga la clave del laboratorio desde el sandbox."""
    return KEY_FILE.read_bytes()


# ---------------------------------------------------------
# 4. Cifrado / descifrado (solo rutas dentro del sandbox)
# ---------------------------------------------------------
# Defensa crítica del script educativo:
#   path.resolve() debe quedar DENTRO de SANDBOX_DIR.
# Así evitamos cifrar por accidente archivos fuera del laboratorio.
# ---------------------------------------------------------

def assert_inside_sandbox(path: Path) -> Path:
    """Valida que el archivo esté estrictamente dentro del sandbox."""
    resolved = path.resolve()
    sandbox = SANDBOX_DIR.resolve()
    if sandbox not in resolved.parents and resolved != sandbox:
        raise PermissionError(
            f"Bloqueado: '{path}' está fuera del sandbox del laboratorio."
        )
    return resolved


def encrypt_file(path: Path, cipher: LabCipher) -> None:
    """Cifra un archivo del sandbox (sobrescribe con datos cifrados)."""
    target = assert_inside_sandbox(path)
    original = target.read_bytes()
    encrypted = cipher.encrypt(original)
    target.write_bytes(encrypted)


def decrypt_file(path: Path, cipher: LabCipher) -> None:
    """Descifra un archivo del sandbox (recupera el contenido original)."""
    target = assert_inside_sandbox(path)
    encrypted = target.read_bytes()
    original = cipher.decrypt(encrypted)
    target.write_bytes(original)


def write_ransom_note() -> None:
    """
    Escribe una nota de rescate EDUCATIVA.
    En ransomware real esta nota intimida y pide pago en criptomonedas.
    Aquí solo explica el concepto para el reporte del estudiante.
    """
    engine = "Fernet (cryptography)" if HAS_FERNET else "cifrado educativo XOR (stdlib)"
    NOTE_FILE.write_text(
        "============================================================\n"
        "NOTA EDUCATIVA DE 'RESCATE' (SIMULACIÓN DE LABORATORIO)\n"
        "============================================================\n"
        "Tus archivos de DEMO dentro de ransomware_lab_sandbox/\n"
        "fueron cifrados temporalmente para explicar cómo funciona\n"
        "un ransomware.\n\n"
        "Esto NO es un ataque real.\n"
        "No se pide dinero.\n"
        "La clave se guardó en lab_key.key dentro del mismo sandbox.\n\n"
        f"Motor de cifrado usado: {engine}\n"
        "El script descifrará automáticamente al final de la demo.\n"
        "============================================================\n",
        encoding="utf-8",
    )


# ---------------------------------------------------------
# 5. Utilidades de presentación para el estudiante
# ---------------------------------------------------------

def preview_file(path: Path, limit: int = 80) -> str:
    """Muestra un adelanto del contenido (texto o bytes cifrados)."""
    data = path.read_bytes()
    try:
        text = data.decode("utf-8")
        return text[:limit].replace("\n", "\\n")
    except UnicodeDecodeError:
        return f"<datos binarios/cifrados: {len(data)} bytes> " + data[:20].hex()


def list_sandbox_files() -> list[Path]:
    """Lista solo los .txt de demo (excluye clave y nota)."""
    return sorted(
        p
        for p in SANDBOX_DIR.glob("*.txt")
        if p.name != NOTE_FILE.name and p.suffix == ".txt"
    )


# ---------------------------------------------------------
# 6. Función: main (orquestación de la demostración)
# ---------------------------------------------------------
# Flujo pedagógico:
#   1) Preparar sandbox con archivos legibles.
#   2) Generar y guardar clave.
#   3) Cifrar solo esos archivos.
#   4) Mostrar nota de rescate educativa.
#   5) Descifrar de nuevo (recuperación / backup conceptual).
#   6) Resumen para el reporte del laboratorio.
# ---------------------------------------------------------

def main() -> None:
    print("=" * 60)
    print("SIMULACIÓN EDUCATIVA DE RANSOMWARE")
    print("Solo afecta la carpeta: ransomware_lab_sandbox/")
    print("=" * 60)

    if HAS_FERNET:
        print("\nMotor: Fernet (paquete cryptography)")
    else:
        print("\nMotor: fallback educativo (stdlib)")
        print("Tip: pip install cryptography  -> usa Fernet real en la demo")

    # 1) Sandbox limpio con archivos de texto
    files = prepare_sandbox()
    print("\n[1] Archivos de demo creados (texto plano):")
    for path in files:
        print(f"  - {path.name}: {preview_file(path)}")

    # 2) Clave simétrica (en un ataque real el atacante la controla)
    key = LabCipher.generate_key()
    save_key(key)
    cipher = LabCipher(key)
    print(f"\n[2] Clave generada y guardada en: {KEY_FILE.name}")

    # 3) Cifrado restringido al sandbox
    print("\n[3] Cifrando archivos del sandbox...")
    for path in files:
        encrypt_file(path, cipher)
        print(f"  - {path.name} CIFRADO -> {preview_file(path)}")

    # 4) Nota de rescate educativa
    write_ransom_note()
    print(f"\n[4] Nota educativa escrita en: {NOTE_FILE.name}")
    print("     (en un ataque real pediría pago; aquí solo explica el laboratorio)")

    # 5) Recuperación: descifrado con la misma clave
    print("\n[5] Descifando (recuperación del laboratorio)...")
    cipher = LabCipher(load_key())
    for path in list_sandbox_files():
        # Evitar intentar descifrar la nota de rescate
        if path.name in DEMO_FILES:
            decrypt_file(path, cipher)
            print(f"  - {path.name} RECUPERADO -> {preview_file(path)}")

    # 6) Cierre pedagógico
    print("\n" + "=" * 60)
    print("ANÁLISIS PARA EL ESTUDIANTE")
    print("=" * 60)
    print("Qué hace un ransomware real:")
    print("  - Cifra muchos archivos del disco (Documentos, fotos, etc.).")
    print("  - Elimina copias o cifra también backups locales.")
    print("  - Exige pago y retiene la clave fuera de tu alcance.")
    print()
    print("Por qué esta demo es segura:")
    print(f"  - Solo opera en: {SANDBOX_DIR.name}/")
    print("  - Valida rutas (assert_inside_sandbox) antes de escribir.")
    print("  - Guarda la clave en el laboratorio y descifra al final.")
    print()
    print("Defensa recomendada (para el reporte):")
    print("  - Copias de seguridad externas / offline.")
    print("  - No abrir adjuntos sospechosos.")
    print("  - Sistema y antivirus actualizados.")
    print("  - Principio de mínimo privilegio.")
    print("=" * 60)
    print("\nDemostración finalizada. Revisa la carpeta ransomware_lab_sandbox/")


# ---------------------------------------------------------
# 7. Punto de entrada
# ---------------------------------------------------------
# Cómo ejecutar:
#   python ransomware_ejemplo.py
#
# (Opcional, para Fernet real):
#   pip install cryptography
#
# Resultado esperado:
#   - Carpeta ransomware_lab_sandbox/ con archivos de demo.
#   - Cifrado visible y luego recuperación automática.
#   - Archivos lab_key.key y LEEAME_RESCATE.txt para el reporte.
# ---------------------------------------------------------

if __name__ == "__main__":
    main()
