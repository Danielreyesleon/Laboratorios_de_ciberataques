"""
================================================================================
LABORATORIO 01 — Scapy: construcción, envío y análisis de paquetes
Curso: CY-302 Programación Avanzada | Clase 11
================================================================================

OBJETIVO DIDÁCTICO
------------------
Que el estudiante comprenda qué es Scapy, cómo se construyen paquetes capa por
capa (Ethernet / IP / TCP / UDP / ICMP) y cómo se usa para un escaneo de
puertos controlado (SYN scan), tal como se presenta en la clase.

REQUISITOS
----------
    pip install scapy
En Windows suele necesitarse Npcap: https://npcap.com/

Ética y entorno
---------------
Ejecutar SOLO contra hosts de laboratorio propios (VM local, localhost, red
aislada del aula). Escanear redes ajenas sin autorización es ilegal.

USO
---
    python 01_scapy_laboratorio.py                 # demo teórica + ping local
    python 01_scapy_laboratorio.py --scan 127.0.0.1 --puertos 20-25,80,443
    python 01_scapy_laboratorio.py --solo-teoria   # sin enviar paquetes
================================================================================
"""

from __future__ import annotations

import argparse
import sys
from typing import Iterable, List


# ---------------------------------------------------------------------------
# Importación de Scapy (con mensaje claro si falta)
# ---------------------------------------------------------------------------
try:
    from scapy.all import (  # type: ignore
        IP,
        TCP,
        UDP,
        ICMP,
        Ether,
        ARP,
        sr1,
        sr,
        RandShort,
        conf,
    )
except ImportError:
    print("[ERROR] Scapy no está instalado. Ejecute: pip install scapy")
    sys.exit(1)


# En entornos de aula a veces conviene silenciar el verbosidad de Scapy
conf.verb = 0


# =============================================================================
# BLOQUE 1 — ¿Qué es Scapy?
# =============================================================================
def explicar_scapy() -> None:
    """Explica el concepto central de Scapy al estudiante."""
    print(
        """
╔══════════════════════════════════════════════════════════════════════════════╗
║  ¿QUÉ ES SCAPY?                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Scapy es una biblioteca de Python para ciberseguridad y redes.              ║
║  Permite:                                                                    ║
║    1) Construir paquetes (craft) campo por campo                             ║
║    2) Enviarlos (send / sr / sr1 / srp)                                      ║
║    3) Capturar y diseccionar respuestas                                      ║
║    4) Crear herramientas propias: scanners, sniffers, pruebas de red         ║
║                                                                              ║
║  Protocolos habituales: Ethernet, ARP, IP, ICMP, TCP, UDP, DNS, etc.         ║
║                                                                              ║
║  Idea clave: un paquete se "apila" con el operador /                         ║
║      IP(dst="1.2.3.4") / TCP(dport=80, flags="S")                            ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    )


# =============================================================================
# BLOQUE 2 — Construcción de paquetes (craft)
# =============================================================================
def demo_construccion_paquetes() -> None:
    """
    Muestra cómo Scapy representa cada capa. NO envía nada a la red.
    Ideal para proyectar en clase y explicar campo por campo.
    """
    print("\n--- DEMO 1: Construcción de paquetes (sin enviar) ---\n")

    # Capa 3: IP
    ip = IP(src="10.0.0.5", dst="10.0.0.1", ttl=64)
    print("[IP] Campos principales:")
    print(f"  src = {ip.src}   dst = {ip.dst}   ttl = {ip.ttl}")
    print(f"  Resumen: {ip.summary()}\n")

    # Capa 4: TCP SYN (como en el escaneo de la diapositiva)
    tcp = TCP(sport=12345, dport=80, flags="S", seq=1000)
    print("[TCP] Flags importantes:")
    print("  S = SYN (inicio de conexión)  |  SA = SYN+ACK (puerto abierto)")
    print("  RA = RST+ACK (puerto cerrado) |  A = ACK")
    print(f"  sport={tcp.sport} dport={tcp.dport} flags={tcp.flags}")
    print(f"  Resumen: {tcp.summary()}\n")

    # Apilado IP + TCP
    paquete = ip / tcp
    print("[PAQUETE COMPUESTO] IP / TCP")
    print(f"  summary : {paquete.summary()}")
    print("  show()  :")
    paquete.show()

    # Otros ejemplos útiles para la clase
    print("\n[ICMP] Eco (ping conceptual):")
    icmp = IP(dst="8.8.8.8") / ICMP()
    print(f"  {icmp.summary()}")

    print("\n[UDP] Consulta conceptual a DNS:")
    udp = IP(dst="8.8.8.8") / UDP(sport=53, dport=53)
    print(f"  {udp.summary()}")

    print("\n[ARP] ¿Quién tiene esta IP? (who-has):")
    arp = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst="192.168.1.1")
    print(f"  {arp.summary()}")


# =============================================================================
# BLOQUE 3 — Envío y recepción: sr1 / sr
# =============================================================================
def demo_ping_icmp(destino: str = "127.0.0.1") -> None:
    """
    Envía un ICMP Echo Request y espera respuesta (sr1 = send/receive one).
    Explica la diferencia entre send() y sr1().
    """
    print(f"\n--- DEMO 2: ICMP Echo (ping) hacia {destino} ---\n")
    print("Funciones de envío en Scapy:")
    print("  send()  → envía en capa 3 y NO espera respuesta")
    print("  sr1()   → envía y espera UNA respuesta (ideal para demos)")
    print("  sr()    → envía y espera MÚLTIPLES respuestas\n")

    paquete = IP(dst=destino) / ICMP()
    print(f"Enviando: {paquete.summary()}")
    respuesta = sr1(paquete, timeout=2)

    if respuesta is None:
        print("Sin respuesta (timeout). ¿El host filtra ICMP?")
    else:
        print("¡Respuesta recibida!")
        print(f"  De: {respuesta.src}")
        print(f"  Tipo ICMP: {respuesta[ICMP].type}  (0 = Echo Reply)")
        respuesta.show()


# =============================================================================
# BLOQUE 4 — Escaneo de puertos (SYN scan) — ejemplo de la diapositiva
# =============================================================================
def parsear_puertos(texto: str) -> List[int]:
    """
    Convierte '20-25,80,443' en [20,21,22,23,24,25,80,443].
    Útil para demos cortas en clase (no escanear 1..1024 completo).
    """
    puertos: List[int] = []
    for parte in texto.split(","):
        parte = parte.strip()
        if not parte:
            continue
        if "-" in parte:
            a, b = parte.split("-", 1)
            puertos.extend(range(int(a), int(b) + 1))
        else:
            puertos.append(int(parte))
    return sorted(set(puertos))


def escanear_puerto(host: str, puerto: int, timeout: float = 1.0) -> str:
    """
    SYN scan de un puerto (técnica de la diapositiva de clase).

    Flujo didáctico:
      1. Creamos IP(dst=host) / TCP(dport=puerto, flags="S")
      2. Enviamos con sr1 y esperamos respuesta
      3. Interpretamos flags TCP:
           SA  → OPEN   (el servicio acepta conexiones)
           RA  → CLOSED (el host respondió con rechazo)
           None→ FILTERED / sin respuesta (firewall o host apagado)
    """
    src_port = RandShort()
    paquete = IP(dst=host) / TCP(sport=src_port, dport=puerto, flags="S")
    respuesta = sr1(paquete, timeout=timeout)

    if respuesta is None:
        return "FILTRADO / sin respuesta"

    if respuesta.haslayer(TCP):
        flags = respuesta[TCP].flags
        # En Scapy, flags puede ser int o str según versión
        flags_str = str(flags)
        if flags == 0x12 or flags_str in ("SA", "AS"):
            # Buena práctica: enviar RST para no dejar half-open
            rst = IP(dst=host) / TCP(sport=src_port, dport=puerto, flags="R")
            sr1(rst, timeout=0.5)
            return "ABIERTO"
        if flags == 0x14 or flags_str in ("RA", "AR"):
            return "CERRADO"
        return f"otro (flags={flags_str})"

    return "respuesta no-TCP"


def port_scan(host: str, port_range: Iterable[int], timeout: float = 1.0) -> None:
    """
    Escaneo de puertos educativo (equivalente al ejemplo de la PPT).

    En clase se recomienda un rango pequeño, p.ej. 20-25,80,443.
    """
    print(f"\n--- DEMO 3: SYN Port Scan → {host} ---\n")
    print("Lógica (igual que en la diapositiva):")
    print('  packet = IP(dst=host)/TCP(sport=RandShort(), dport=p, flags="S")')
    print("  response = sr1(packet, timeout=...)")
    print('  si flags == "SA" → puerto abierto\n')

    abiertos = []
    for puerto in port_range:
        estado = escanear_puerto(host, puerto, timeout=timeout)
        marca = "★" if estado == "ABIERTO" else " "
        print(f"  {marca} Puerto {puerto:5d} → {estado}")
        if estado == "ABIERTO":
            abiertos.append(puerto)

    print("\nResumen de puertos abiertos:", abiertos or "(ninguno detectado)")


# =============================================================================
# BLOQUE 5 — Disección: leer un paquete recibido campo a campo
# =============================================================================
def demo_diseccion(host: str = "127.0.0.1") -> None:
    """Muestra cómo acceder a capas y campos de un paquete recibido."""
    print(f"\n--- DEMO 4: Disección de respuesta desde {host} ---\n")
    resp = sr1(IP(dst=host) / ICMP(), timeout=2)
    if resp is None:
        print("Sin respuesta para diseccionar.")
        return

    print("Acceso por capa (como un diccionario de protocolos):")
    print(f"  resp[IP].src   = {resp[IP].src}")
    print(f"  resp[IP].dst   = {resp[IP].dst}")
    print(f"  resp[IP].ttl   = {resp[IP].ttl}")
    if resp.haslayer(ICMP):
        print(f"  resp[ICMP].type = {resp[ICMP].type}")
    print("\nHexdump / representación:")
    print(resp.command())  # código Scapy equivalente al paquete


# =============================================================================
# CLI — menú didáctico
# =============================================================================
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Laboratorio didáctico de Scapy (CY-302 Clase 11)"
    )
    parser.add_argument(
        "--solo-teoria",
        action="store_true",
        help="Solo explica y construye paquetes; no envía nada a la red",
    )
    parser.add_argument(
        "--scan",
        metavar="HOST",
        help="Host de laboratorio a escanear (ej. 127.0.0.1)",
    )
    parser.add_argument(
        "--puertos",
        default="20-25,80,443",
        help="Lista/rangos de puertos (default: 20-25,80,443)",
    )
    parser.add_argument(
        "--ping",
        metavar="HOST",
        default="127.0.0.1",
        help="Destino ICMP para la demo de ping (default: 127.0.0.1)",
    )
    args = parser.parse_args()

    explicar_scapy()
    demo_construccion_paquetes()

    if args.solo_teoria:
        print("\n[Modo --solo-teoria] No se enviaron paquetes. Fin del laboratorio.")
        return

    print(
        "\n⚠  Aviso: a partir de aquí se envían paquetes reales a la red local.\n"
        "   Use solo hosts de laboratorio autorizados.\n"
    )

    demo_ping_icmp(args.ping)
    demo_diseccion(args.ping)

    if args.scan:
        puertos = parsear_puertos(args.puertos)
        port_scan(args.scan, puertos)
    else:
        print(
            "\nTip: para el escaneo de la diapositiva ejecute:\n"
            "  python 01_scapy_laboratorio.py --scan 127.0.0.1 --puertos 20-25,80,443\n"
        )


if __name__ == "__main__":
    main()
