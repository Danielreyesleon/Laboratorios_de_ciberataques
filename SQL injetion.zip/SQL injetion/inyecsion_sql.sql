¿Cómo ocurre una inyección SQL? (Paso a paso)
1. El usuario abre una pantalla de inicio de sesión
La aplicación muestra dos campos:
Usuario
Contraseña
El usuario escribe información y presiona Iniciar sesión.
2. La aplicación recibe los datos
La aplicación toma lo que escribió el usuario.
Por ejemplo:
Usuario: Luis
Contraseña: 12345
3. El programador construye la consulta
Si el programador lo hace de forma insegura, la aplicación 
une (concatena) el texto del usuario con la consulta SQL.
Ejemplo conceptual:
Consulta SQL
      +
Lo que escribió el usuario
      +
Más consulta SQL
4. SQL Server recibe la consulta
SQL Server no sabe qué parte escribió el usuario.
Solo recibe una consulta completa y la intenta ejecutar.
Es como un cocinero que recibe una orden escrita y la sigue al pie de la letra.
5. Si la aplicación no valida correctamente la entrada...
Una persona puede introducir texto que cambie el significado de la consulta.
El problema no es SQL Server.
El problema es que la aplicación permitió que la entrada del usuario 
modificara la consulta.
6. La consulta puede comportarse de forma diferente
Dependiendo del error de programación, la aplicación podría:
devolver información incorrecta;
permitir el acceso cuando no debería;
mostrar datos que no correspondían a la solicitud.
7. ¿Cómo se evita?
La solución consiste en:
Usar consultas parametrizadas.
Validar los datos que ingresan los usuarios.
Evitar concatenar texto del usuario para formar consultas SQL.
Aplicar el principio de mínimo privilegio en la base de datos.
Imagina que llamas a una pizzería.
El empleado pregunta:
¿Qué pizza desea?
La respuesta esperada es:
Pizza de jamón.
Pero si el empleado copia todo lo que diga el cliente como si fuera 
parte de la orden interna, cualquier texto inesperado 
podría alterar la orden.
Una aplicación insegura hace exactamente eso: copia y pega la 
entrada del usuario dentro de la consulta.
Una aplicación segura, en cambio, tiene un formulario donde el tipo de 
pizza es solo un dato. No importa qué escriba el cliente, ese texto nunca 
cambia la lógica del sistema; únicamente se trata como el valor del pedido.
*/
use db_jardineria
go
------------------------------------------------------
select * 
from cliente
where 
nombre_contacto ='Luis';
------------------------------------------------------
create table Usuarios (
    IdUsuario int IDENTITY(1,1) PRIMARY KEY,
    Usuario varchar(50) NOT NULL,
    Contrasena varchar(50) NOT NULL,
    NombreCompleto varchar(100),
    Rol varchar(20)
);
go
-----------------------------------------------------------------
insert into Usuarios (Usuario, Contrasena, NombreCompleto, Rol)
values
('admin','Admin123','Administrador del Sistema','Administrador'),
('luis','Luis123','Luis Bermúdez','Profesor'),
('maria','Maria123','María Gómez','Estudiante'),
('juan','Juan123','Juan Pérez','Estudiante');
go
--------------------------------------------------------------------
select *
from Usuarios
where Usuario = '<usuario>'
AND Contrasena = '<password>';
--consulta normal---
select *
from Usuarios
where Usuario = 'luis'
AND Contrasena = 'Luis123';
---------------------------------------------------------------------
DECLARE @usuario VARCHAR(50) = ''' OR ''1''=''1';
DECLARE @sql NVARCHAR(MAX);
SET @sql =
'SELECT *
FROM Usuarios
WHERE Usuario = ''' + @usuario + '''';
PRINT @sql;

SELECT *
FROM Usuarios
WHERE Usuario = '' OR '1'='1'