# ---------------------------------------------------------
# Script: simulación educativa de un keylogger
# Curso: CY-302 Programación Avanzada — Semana 10
# ---------------------------------------------------------
# Contexto del laboratorio:
# Un keylogger es un programa que registra las teclas pulsadas
# por el usuario. En ataques reales se usa para robar contraseñas,
# mensajes u otra información sensible, a menudo de forma oculta.
#
# Versión ORIGINAL (NO segura — no ejecutar en equipos reales):
# - Usaba pynput.keyboard.Listener para capturar teclas del sistema.
# - Guardaba TODAS las pulsaciones en log.txt sin aviso claro.
# - Eso es vigilancia real del teclado y puede usarse de forma ilegal.
#
# Objetivo de ESTA versión (segura / educativa):
# - Explicar el FLUJO conceptual de un keylogger.
# - NO instalar hooks globales del teclado.
# - NO capturar teclas fuera de esta consola de forma silenciosa.
# - Ofrecer dos modos controlados:
#     1) Simulación automática (por defecto)
#     2) Demostración interactiva con input() (el estudiante escribe
#        a propósito en la consola y ve cómo se "registraría")
# - Guardar un archivo de demo claramente etiquetado como educativo.
# ---------------------------------------------------------

from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------
# 1. Configuración del laboratorio
# ---------------------------------------------------------
# LOG_FILE: archivo de salida de la demostración.
# Se guarda en la misma carpeta del script para fácil revisión
# en el reporte. El nombre deja claro que es una demo, no un
# registro furtivo del sistema.
# ---------------------------------------------------------

LOG_FILE = Path(__file__).with_name("keylogger_demo_log.txt")

# Secuencia simulada: representa lo que un keylogger vería
# si un usuario escribiera una contraseña y enviara un formulario.
# Son datos FICTICIOS; no provienen del teclado real.
SIMULATED_KEYSTROKES = [
    "u", "s", "u", "a", "r", "i", "o",
    "[TAB]",
    "C", "l", "a", "v", "e", "1", "2", "3", "!",
    "[ENTER]",
]


# ---------------------------------------------------------
# 2. Función: format_key
# ---------------------------------------------------------
# Propósito:
#   Normalizar cada "tecla" a un texto legible para el log.
#   En un keylogger real, las teclas especiales (Enter, Shift, etc.)
#   también se registran; aquí lo ilustramos con etiquetas [ENTER],
#   [TAB], etc.
# ---------------------------------------------------------

def format_key(key: str) -> str:
    """Normaliza una tecla simulada a texto de log."""
    return key if key.startswith("[") else key


# ---------------------------------------------------------
# 3. Función: write_log
# ---------------------------------------------------------
# Propósito:
#   Escribir el registro de la demo en disco, con encabezado
#   educativo para que quede documentado en el laboratorio.
#
# Diferencia vs código malicioso:
#   Malicioso -> escribe en silencio, a veces oculto o cifrado.
#   Educativo -> encabezado explícito + archivo con nombre claro.
# ---------------------------------------------------------

def write_log(keys: list[str], mode: str) -> None:
    """Guarda el registro de la demostración en un archivo de texto."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with LOG_FILE.open("w", encoding="utf-8") as f:
        f.write("=" * 60 + "\n")
        f.write("REGISTRO EDUCATIVO DE KEYLOGGER (SIMULACIÓN)\n")
        f.write("NO es captura furtiva del sistema.\n")
        f.write(f"Fecha: {timestamp}\n")
        f.write(f"Modo:  {mode}\n")
        f.write("=" * 60 + "\n\n")
        for key in keys:
            f.write(format_key(key) + "\n")
        f.write("\n" + "-" * 60 + "\n")
        f.write("Texto reconstruido (aproximación):\n")
        f.write(reconstruct_text(keys) + "\n")


# ---------------------------------------------------------
# 4. Función: reconstruct_text
# ---------------------------------------------------------
# Propósito:
#   Mostrar por qué un keylogger es peligroso: a partir de teclas
#   sueltas se puede reconstruir usuario, contraseña o mensajes.
#   [TAB] e [ENTER] se interpretan como separadores/fin de línea.
# ---------------------------------------------------------

def reconstruct_text(keys: list[str]) -> str:
    """Reconstruye texto legible a partir de la secuencia de teclas."""
    parts: list[str] = []
    current = []
    for key in keys:
        if key == "[TAB]":
            parts.append("".join(current))
            current = []
            parts.append("  [campo siguiente]  ")
        elif key == "[ENTER]":
            parts.append("".join(current))
            current = []
            parts.append("  [enviar]")
        elif key.startswith("[") and key.endswith("]"):
            # Otras teclas especiales: se omiten en la reconstrucción simple
            continue
        else:
            current.append(key)
    if current:
        parts.append("".join(current))
    return "".join(parts)


# ---------------------------------------------------------
# 5. Función: run_simulation
# ---------------------------------------------------------
# Modo por defecto del laboratorio.
# No lee el teclado del sistema: reproduce una secuencia inventada
# y muestra en pantalla cada "pulsación", como haría un keylogger
# al ir acumulando eventos.
# ---------------------------------------------------------

def run_simulation() -> list[str]:
    """Ejecuta una captura 100% simulada (sin leer el teclado real)."""
    print("\n[Modo SIMULACIÓN] Reproduciendo tecleo ficticio...\n")
    keys: list[str] = []
    for key in SIMULATED_KEYSTROKES:
        keys.append(key)
        print(f"  tecla capturada (simulada): {format_key(key)}")
    return keys


# ---------------------------------------------------------
# 6. Función: run_interactive
# ---------------------------------------------------------
# Demostración consciente: el estudiante escribe UNA línea en la
# consola con input(). Solo se registra lo que él/ella decide
# escribir aquí; no hay listener global del sistema (pynput).
#
# Para el reporte: esto ilustra el "efecto" de registrar entrada,
# pero con consentimiento y alcance limitado a esta terminal.
# ---------------------------------------------------------

def run_interactive() -> list[str]:
    """
    Demostración interactiva controlada.
    Solo registra lo que el estudiante escribe con input().
    """
    print("\n[Modo INTERACTIVO] Escribe una frase de prueba y pulsa Enter.")
    print("Solo se registrará esta línea (no todo el teclado del sistema).\n")
    text = input("> ")

    keys: list[str] = []
    for ch in text:
        # Espacio se etiqueta para que el log sea más claro en el reporte
        keys.append("[SPACE]" if ch == " " else ch)
    keys.append("[ENTER]")

    print("\nTeclas registradas desde la entrada consciente:")
    for key in keys:
        print(f"  tecla: {format_key(key)}")
    return keys


# ---------------------------------------------------------
# 7. Función: show_analysis
# ---------------------------------------------------------
# Cierre pedagógico: resume el riesgo y qué se generó en disco.
# ---------------------------------------------------------

def show_analysis(keys: list[str]) -> None:
    """Muestra el análisis educativo al final de la demo."""
    print("\n" + "=" * 60)
    print("ANÁLISIS PARA EL ESTUDIANTE")
    print("=" * 60)
    print(f"Total de eventos registrados: {len(keys)}")
    print(f"Texto reconstruido: {reconstruct_text(keys)}")
    print(f"Archivo generado:   {LOG_FILE.name}")
    print()
    print("Riesgo en un keylogger REAL:")
    print("  - Puede capturar contraseñas, correos y datos bancarios.")
    print("  - Suele ejecutarse oculto y enviar datos a un atacante.")
    print()
    print("Por qué esta demo es segura:")
    print("  - No usa Listener global del teclado (pynput).")
    print("  - No captura pulsaciones fuera de esta demostración.")
    print("  - El archivo de log está etiquetado como educativo.")
    print("=" * 60)


# ---------------------------------------------------------
# 8. Función: main (orquestación)
# ---------------------------------------------------------
# Flujo:
#   1) Explicar el propósito.
#   2) Preguntar el modo (Enter = simulación; 2 = interactivo).
#   3) Registrar teclas (simuladas o conscientes).
#   4) Guardar log de demo.
#   5) Mostrar análisis para el reporte del laboratorio.
# ---------------------------------------------------------

def main() -> None:
    print("=" * 60)
    print("SIMULACIÓN EDUCATIVA DE KEYLOGGER")
    print("Sin captura furtiva del teclado del sistema.")
    print("=" * 60)
    print()
    print("Elige el modo de demostración:")
    print("  1) Simulación automática  (recomendado / por defecto)")
    print("  2) Interactivo con input() (escribes una línea a propósito)")
    print()

    choice = input("Opción [1/2] (Enter = 1): ").strip() or "1"

    if choice == "2":
        mode = "interactivo (input consciente)"
        keys = run_interactive()
    else:
        mode = "simulacion automatica"
        keys = run_simulation()

    write_log(keys, mode)
    show_analysis(keys)
    print("\nDemostración finalizada.")


# ---------------------------------------------------------
# 9. Punto de entrada del script
# ---------------------------------------------------------
# Cómo ejecutar en el laboratorio:
#   python keylogger_ejemplo.py
#
# Resultado esperado:
#   - Impresión de teclas (simuladas o de la línea escrita).
#   - Creación de keylogger_demo_log.txt en la misma carpeta.
#   - Resumen de riesgos y medidas de seguridad educativas.
# ---------------------------------------------------------

if __name__ == "__main__":
    main()
