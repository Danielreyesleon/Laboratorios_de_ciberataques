# ---------------------------------------------------------
# Script: simulación educativa de un bot / reverse shell (C2)
# Curso: CY-302 Programación Avanzada — Semana 10
# ---------------------------------------------------------
# Contexto del laboratorio:
# En ciberseguridad, un "bot" o reverse shell es un programa que
# se ejecuta en una máquina víctima, se conecta a un servidor
# controlado por un atacante (C2 = Command and Control) y espera
# órdenes remotas. Esas órdenes suelen ejecutarse en el sistema
# operativo y el resultado se envía de vuelta al atacante.
#
# Versión ORIGINAL (NO segura — no ejecutar tal cual):
# - Se conectaba a una IP remota (servidor del atacante).
# - Recibía comandos arbitrarios por la red.
# - Los ejecutaba con os.popen(), afectando el equipo real.
#
# Objetivo de ESTA versión (segura / educativa):
# - Demostrar el FLUJO de comunicación cliente-servidor de un bot.
# - NO ejecutar comandos reales del sistema operativo.
# - Limitar la red a localhost (127.0.0.1), sin Internet.
# - Responder solo con textos simulados de una lista permitida.
# - Permitir documentar el laboratorio sin riesgo para el equipo.
# ---------------------------------------------------------

# socket  -> comunicación TCP entre "servidor C2" y "bot"
# threading -> ejecutar el servidor C2 en paralelo con el bot
# time    -> pequeñas pausas para que la demo se lea con claridad
import socket
import threading
import time

# ---------------------------------------------------------
# 1. Configuración de red (solo entorno local de laboratorio)
# ---------------------------------------------------------
# HOST = "127.0.0.1" (loopback):
#   La comunicación ocurre ÚNICAMENTE dentro de esta misma máquina.
#   No se envían datos a Internet ni a otras computadoras de la red.
#
# PORT = 1234:
#   Puerto TCP de demostración. Debe coincidir en servidor y cliente.
#   En un ataque real, el atacante elegiría una IP pública y un puerto
#   abierto; aquí todo queda encapsulado en el laboratorio local.
# ---------------------------------------------------------

HOST = "127.0.0.1"
PORT = 1234

# ---------------------------------------------------------
# 2. Diccionario de comandos seguros (whitelist)
# ---------------------------------------------------------
# En el malware real, el bot ejecutaría CUALQUIER cadena recibida
# (por ejemplo: "dir", "whoami", "del archivo", etc.) mediante
# os.popen() o subprocess, con acceso real al sistema.
#
# Aquí hacemos lo contrario: solo reconocemos unos pocos comandos
# de demostración y devolvemos TEXTO FIJO. El sistema operativo
# nunca se consulta ni se modifica.
#
# Esto ilustra un principio de defensa: listas blancas (allowlists)
# frente a ejecución abierta de entradas no confiables.
# ---------------------------------------------------------

SAFE_COMMANDS = {
    "help": (
        "Comandos simulados disponibles:\n"
        "  help     - muestra esta ayuda\n"
        "  whoami   - identidad simulada del bot\n"
        "  hostname - nombre de host simulado\n"
        "  pwd      - directorio simulado\n"
        "  ls       - listado simulado de archivos\n"
        "  status   - estado del bot simulado\n"
        "  exit     - cierra la sesión del bot\n"
    ),
    "whoami": "bot_educativo_01\n",
    "hostname": "lab-ciberseguridad.local\n",
    "pwd": "/home/estudiante/lab_semana10\n",
    "ls": "boot.py\nmain.py\ncommon_passwords.txt\npassword_hashes.txt\n",
    "status": "OK | modo=simulacion | riesgo=ninguno | destino=localhost\n",
}


# ---------------------------------------------------------
# 3. Función: simulate_command
# ---------------------------------------------------------
# Propósito:
#   Traducir un "comando" recibido por red a una respuesta de texto,
#   sin invocar el shell del sistema.
#
# Flujo:
#   1) Normalizar la cadena (strip + lower) para comparar de forma estable.
#   2) Si está vacío, informar al laboratorio.
#   3) Si está en SAFE_COMMANDS, devolver la respuesta asociada.
#   4) Si no está permitido, rechazarlo con un mensaje claro.
#
# Diferencia clave vs código malicioso:
#   Malicioso  -> output = os.popen(command).read()
#   Educativo  -> output = texto simulado / rechazo
# ---------------------------------------------------------

def simulate_command(command: str) -> str:
    """Devuelve una respuesta simulada. Nunca ejecuta el sistema."""
    cmd = command.strip().lower()
    if not cmd:
        return "(comando vacío)\n"
    if cmd in SAFE_COMMANDS:
        return SAFE_COMMANDS[cmd]
    return (
        f"[simulación] Comando '{command.strip()}' no está en la lista segura.\n"
        "Usa 'help' para ver los comandos permitidos.\n"
    )


# ---------------------------------------------------------
# 4. Función: run_fake_c2_server (servidor Command & Control simulado)
# ---------------------------------------------------------
# En un escenario real, el C2 sería un servidor remoto del atacante
# que:
#   - Escucha conexiones entrantes de bots infectados.
#   - Envía órdenes (reconocimiento, exfiltración, persistencia, etc.).
#   - Recibe y almacena las salidas.
#
# En este laboratorio, el "C2" corre en el mismo script, en un hilo
# aparte, y solo envía una secuencia fija de comandos de demo.
#
# Pasos técnicos:
#   a) Crear socket TCP (AF_INET + SOCK_STREAM).
#   b) SO_REUSEADDR: permite reutilizar el puerto tras reiniciar el script.
#   c) bind + listen: abrir el puerto en localhost.
#   d) ready_event.set(): avisar a main() de que ya puede conectar el bot.
#   e) accept(): esperar la conexión del bot.
#   f) Enviar cada comando, recibir respuesta y mostrarla en consola.
#   g) Cerrar conexión y socket al terminar (bloque finally).
# ---------------------------------------------------------

def run_fake_c2_server(ready_event: threading.Event) -> None:
    """
    Servidor C2 falso en localhost.
    Envía unos comandos de demo y muestra las respuestas del bot.
    """
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(1)
    ready_event.set()
    print(f"[C2 simulado] Escuchando en {HOST}:{PORT}")

    # Bloquea hasta que el bot se conecte (una sola conexión de demo)
    conn, addr = server.accept()
    print(f"[C2 simulado] Bot conectado desde {addr}")

    # Secuencia pedagógica: ayuda -> identidad -> entorno -> cierre
    demo_commands = ["help", "whoami", "hostname", "pwd", "ls", "status", "exit"]
    try:
        for command in demo_commands:
            print(f"\n[C2 simulado] Enviando: {command}")
            # encode: convierte str de Python a bytes para enviar por TCP
            conn.sendall(command.encode("utf-8"))
            # recv: lee la respuesta del bot (máx. 4096 bytes en esta demo)
            response = conn.recv(4096).decode("utf-8", errors="replace")
            print(f"[C2 simulado] Respuesta:\n{response}")
            # Pausa breve solo para que el reporte en pantalla sea legible
            time.sleep(0.3)
    finally:
        # Siempre liberar recursos de red, aunque ocurra un error
        conn.close()
        server.close()
        print("\n[C2 simulado] Demostración finalizada.")


# ---------------------------------------------------------
# 5. Función: bot (cliente / "máquina víctima" simulada)
# ---------------------------------------------------------
# Representa el programa que, en un ataque real, residiría en la
# víctima. Su ciclo típico es:
#   1) Conectarse al C2.
#   2) Esperar (bucle while) un comando.
#   3) Ejecutarlo / procesarlo.
#   4) Devolver la salida.
#
# Medidas de seguridad aplicadas aquí:
#   - connect solo a 127.0.0.1 (no IP externa).
#   - Procesamiento con simulate_command (sin os.popen / subprocess).
#   - Comando "exit" para terminar el bucle de forma controlada.
#   - Cierre del socket en finally para no dejar puertos colgados.
#
# Nota para el reporte:
#   El bucle while True + recv/sendall es el patrón conceptual del
#   reverse shell; lo peligroso no es el socket en sí, sino ejecutar
#   entradas remotas sin validación sobre el sistema operativo.
# ---------------------------------------------------------

def bot() -> None:
    """
    Cliente 'bot' educativo.
    Se conecta solo a localhost y responde con salidas simuladas.
    """
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((HOST, PORT))
    print(f"[Bot] Conectado a C2 simulado en {HOST}:{PORT}")

    try:
        while True:
            # Si recv() devuelve b'', el servidor cerró la conexión
            data = client.recv(1024)
            if not data:
                break

            command = data.decode("utf-8", errors="replace")
            print(f"[Bot] Comando recibido: {command.strip()}")

            # Condición de salida limpia de la sesión simulada
            if command.strip().lower() == "exit":
                client.sendall(b"Sesion simulada cerrada.\n")
                break

            # IMPORTANTE (laboratorio):
            # Aquí NO se usa os.popen() ni subprocess.
            # Esa fue la línea crítica del código original inseguro.
            output = simulate_command(command)
            client.sendall(output.encode("utf-8"))
    finally:
        client.close()
        print("[Bot] Desconectado.")


# ---------------------------------------------------------
# 6. Función: main (orquestación de la demostración)
# ---------------------------------------------------------
# Orden de arranque (importante para evitar errores de conexión):
#   1) Crear un Event de sincronización (ready).
#   2) Lanzar el servidor C2 en un hilo (daemon=True).
#   3) Esperar a que el servidor indique que ya está escuchando.
#   4) Iniciar el bot (cliente) en el hilo principal.
#   5) Esperar a que el hilo del servidor termine la demo.
#
# Así, un solo archivo y un solo comando (python boot.py) bastan
# para reproducir el escenario completo en el laboratorio.
# ---------------------------------------------------------

def main() -> None:
    print("=" * 60)
    print("SIMULACIÓN EDUCATIVA DE BOT / REVERSE SHELL")
    print("Sin ejecución real de comandos. Solo localhost.")
    print("=" * 60)

    ready = threading.Event()
    server_thread = threading.Thread(
        target=run_fake_c2_server,
        args=(ready,),
        daemon=True,
    )
    server_thread.start()
    # Espera hasta 5 s a que el C2 haga bind/listen y avise con ready.set()
    ready.wait(timeout=5)

    # Margen mínimo adicional antes de connect del bot
    time.sleep(0.2)
    bot()
    # join: no terminar el programa hasta que el C2 cierre su demo
    server_thread.join(timeout=5)


# ---------------------------------------------------------
# 7. Punto de entrada del script
# ---------------------------------------------------------
# if __name__ == "__main__":
#   Garantiza que main() solo se ejecute al correr este archivo
#   directamente (python boot.py), no si se importa desde otro módulo.
#
# Cómo ejecutar en el laboratorio:
#   python boot.py
#
# Resultado esperado:
#   Mensajes intercalados de [C2 simulado] y [Bot] mostrando el
#   intercambio de comandos y respuestas simuladas, y cierre limpio.
# ---------------------------------------------------------

if __name__ == "__main__":
    main()
