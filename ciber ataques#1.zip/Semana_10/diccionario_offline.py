# ---------------------------------------------------------
# Script: simulación educativa de ataque de diccionario OFFLINE
# Curso: CY-302 Programación Avanzada — Semana 10
# ---------------------------------------------------------
# Contexto del laboratorio:
# Un ataque de diccionario "offline" no habla con un servidor.
# El atacante ya tiene un HASH (por ejemplo filtrado de una BD)
# y calcula el hash de muchas contraseñas candidatas hasta
# encontrar una coincidencia.
#
# Versión ORIGINAL:
# - Ya era relativamente segura (solo hashlib local).
# - Usaba una lista corta embebida y el hash de "password".
#
# Objetivo de ESTA versión (mejorada para el laboratorio):
# - Mantener el enfoque 100% local (sin red).
# - Cargar candidatos desde common_passwords.txt si existe.
# - Probar uno o varios hashes de password_hashes.txt.
# - Documentar diferencias ONLINE vs OFFLINE para el reporte.
# - Dejar claro que esto es auditoría educativa de contraseñas débiles.
# ---------------------------------------------------------

from __future__ import annotations

import hashlib
from pathlib import Path

# ---------------------------------------------------------
# 1. Rutas de archivos del laboratorio
# ---------------------------------------------------------
# Se reutilizan los mismos recursos que main.py:
#   - common_passwords.txt  -> diccionario de candidatos
#   - password_hashes.txt   -> hashes "filtrados" de ejemplo
# ---------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
PASSWORDS_FILE = BASE_DIR / "common_passwords.txt"
HASHES_FILE = BASE_DIR / "password_hashes.txt"

# Hash de respaldo (SHA-256 de la palabra "password") por si no
# existe el archivo de hashes. Útil para que el script siempre demuestre algo.
FALLBACK_HASH = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8"
FALLBACK_PASSWORDS = ["123456", "password", "admin", "welcome", "abc123"]


# ---------------------------------------------------------
# 2. Carga de diccionario y hashes
# ---------------------------------------------------------

def load_passwords() -> list[str]:
    """Carga contraseñas candidatas desde archivo o usa lista de respaldo."""
    if PASSWORDS_FILE.exists():
        passwords = [
            line.strip()
            for line in PASSWORDS_FILE.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        print(f"Diccionario cargado desde: {PASSWORDS_FILE.name} ({len(passwords)} palabras)")
        return passwords

    print("No se encontró common_passwords.txt; usando lista de respaldo.")
    return list(FALLBACK_PASSWORDS)


def load_target_hashes() -> list[str]:
    """Carga hashes objetivo desde archivo o usa el hash de 'password'."""
    if HASHES_FILE.exists():
        hashes = [
            line.strip().lower()
            for line in HASHES_FILE.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        print(f"Hashes cargados desde: {HASHES_FILE.name} ({len(hashes)} hashes)")
        return hashes

    print("No se encontró password_hashes.txt; usando hash de demo ('password').")
    return [FALLBACK_HASH]


# ---------------------------------------------------------
# 3. Función: sha256_hex
# ---------------------------------------------------------
# Calcula el digest SHA-256 en hexadecimal (64 caracteres).
# Es el mismo proceso conceptual que en main.py.
# ---------------------------------------------------------

def sha256_hex(password: str) -> str:
    """Devuelve el hash SHA-256 hexadecimal de una contraseña."""
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


# ---------------------------------------------------------
# 4. Función: guess_password (ataque offline a UN hash)
# ---------------------------------------------------------
# Recorre el diccionario, hashea cada candidato y compara.
# Tan pronto encuentra coincidencia, detiene la búsqueda de ese hash.
#
# Diferencia clave vs online:
#   Offline -> solo CPU/disco local; ilimitado por el servidor.
#   Online  -> cada intento es una autenticación remota.
# ---------------------------------------------------------

def guess_password(target_hash: str, passwords: list[str]) -> str | None:
    """
    Intenta recuperar la contraseña en texto plano a partir de su hash.
    Retorna la contraseña si hay coincidencia; si no, None.
    """
    target_hash = target_hash.lower().strip()
    print(f"\nObjetivo hash: {target_hash}")

    for index, password in enumerate(passwords, start=1):
        guess_hash = sha256_hex(password)
        if guess_hash == target_hash:
            print(f"  [ÉXITO] Intento {index}: '{password}'")
            return password

    print("  [FALLO] No se pudo adivinar la contraseña con este diccionario.")
    return None


# ---------------------------------------------------------
# 5. Función: main
# ---------------------------------------------------------

def main() -> None:
    print("=" * 60)
    print("SIMULACIÓN EDUCATIVA: ATAQUE DE DICCIONARIO OFFLINE")
    print("Solo hashing local (SHA-256). Sin red.")
    print("=" * 60)

    passwords = load_passwords()
    target_hashes = load_target_hashes()

    found_count = 0
    results: list[tuple[str, str | None]] = []

    for target_hash in target_hashes:
        cracked = guess_password(target_hash, passwords)
        results.append((target_hash, cracked))
        if cracked:
            found_count += 1

    print("\n" + "=" * 60)
    print("RESUMEN")
    print("=" * 60)
    print(f"Hashes analizados:     {len(target_hashes)}")
    print(f"Contraseñas rotas:     {found_count}")
    print(f"Tamaño del diccionario:{len(passwords)}")
    print()
    for target_hash, cracked in results:
        short = target_hash[:16] + "..."
        if cracked:
            print(f"  {short}  ->  '{cracked}'")
        else:
            print(f"  {short}  ->  (sin coincidencia)")

    print("\n" + "=" * 60)
    print("ANÁLISIS PARA EL ESTUDIANTE")
    print("=" * 60)
    print("Qué hace un ataque OFFLINE real:")
    print("  - Parte de hashes robados (filtración de base de datos).")
    print("  - Prueba millones de candidatos con mucha CPU/GPU.")
    print("  - No alerta al servidor de login (ya tiene los hashes).")
    print()
    print("ONLINE vs OFFLINE:")
    print("  - Online:  intenta login remoto; lento y detectable.")
    print("  - Offline: compara hashes en local; rápido y silencioso.")
    print()
    print("Por qué esta demo es segura:")
    print("  - No se conecta a ningún servicio.")
    print("  - Solo usa hashes/diccionarios del laboratorio.")
    print("  - Sirve para auditar contraseñas DÉBILES de ejemplo.")
    print()
    print("Defensas recomendadas (para el reporte):")
    print("  - Contraseñas largas y no presentes en diccionarios.")
    print("  - Almacenar contraseñas con hash + salt (p. ej. bcrypt/argon2).")
    print("  - No reutilizar credenciales entre sitios.")
    print("  - MFA para reducir el impacto si hay filtración.")
    print("=" * 60)
    print("\nDemostración finalizada.")


# ---------------------------------------------------------
# 6. Punto de entrada
# ---------------------------------------------------------
# Ejecutar:
#   python diccionario_offline.py
#
# Relacionado:
#   - main.py              -> detector de contraseñas débiles
#   - diccionario_online.py -> misma idea pero contra un login simulado
# ---------------------------------------------------------

if __name__ == "__main__":
    main()
