# ---------------------------------------------------------
# Script: simulación educativa de ataque de diccionario ONLINE
# Curso: CY-302 Programación Avanzada — Semana 10
# ---------------------------------------------------------
# Contexto del laboratorio:
# Un ataque de diccionario "online" intenta autenticarse muchas
# veces contra un servicio real (FTP, SSH, web, etc.) probando
# contraseñas de una lista hasta acertar o ser bloqueado.
#
# Versión ORIGINAL (NO segura / no ética tal cual):
# - Usaba ftplib.FTP para conectarse a un host remoto.
# - Probaba varias contraseñas contra ese servidor real.
# - Atacar sistemas ajenos sin autorización es ilegal.
#
# Objetivo de ESTA versión (segura / educativa):
# - Explicar el FLUJO de un ataque online por diccionario.
# - NO conectar a Internet ni a servidores externos.
# - Usar un "servidor FTP falso" en memoria (simulación).
# - Mostrar éxitos/fallos y medidas de defensa.
# ---------------------------------------------------------

from dataclasses import dataclass

# ---------------------------------------------------------
# 1. Credenciales y diccionario de la DEMO (datos ficticios)
# ---------------------------------------------------------
# En un ataque real el atacante elegiría un host/usuario ajenos.
# Aquí TODO es inventado y local: no hay red.
# ---------------------------------------------------------

DEMO_HOST = "ftp.laboratorio.local"  # No se resuelve en Internet
DEMO_USER = "estudiante"
# Contraseña "correcta" del servicio simulado (solo para la demo)
CORRECT_PASSWORD = "welcome"

# Lista corta de candidatos (diccionario). También se podría leer
# desde common_passwords.txt; aquí va embebida para que el script
# sea autocontenido y fácil de explicar en clase.
PASSWORD_DICTIONARY = [
    "password1",
    "password2",
    "123456",
    "password",
    "admin",
    "welcome",  # <- esta coincidirá con CORRECT_PASSWORD
    "abc123",
]


# ---------------------------------------------------------
# 2. Servicio FTP SIMULADO (sin sockets ni red)
# ---------------------------------------------------------
# Representa el servidor remoto. Solo acepta un usuario/clave.
# Si la clave es incorrecta, "lanza" un error de autenticación,
# igual que haría un FTP real al fallar login().
# ---------------------------------------------------------

@dataclass
class FakeFTPServer:
    host: str
    valid_user: str
    valid_password: str

    def login(self, user: str, password: str) -> None:
        """Simula FTP.login(). Falla si las credenciales no coinciden."""
        if user == self.valid_user and password == self.valid_password:
            return
        raise PermissionError("530 Login incorrect.")


# ---------------------------------------------------------
# 3. Función: try_login (un intento del ataque)
# ---------------------------------------------------------
# Equivale al try_login original, pero contra FakeFTPServer.
# No usa ftplib ni abre conexiones TCP.
# ---------------------------------------------------------

def try_login(server: FakeFTPServer, user: str, password: str) -> bool:
    """
    Intenta un login simulado.
    Retorna True si acertó, False si falló.
    """
    try:
        server.login(user, password)
        print(f"  [ÉXITO] Usuario='{user}'  Password='{password}'")
        return True
    except PermissionError:
        print(f"  [FALLO]  Password='{password}'")
        return False


# ---------------------------------------------------------
# 4. Función: dictionary_attack_online (bucle del diccionario)
# ---------------------------------------------------------
# Recorre la lista de contraseñas una por una (ataque online).
# En la vida real esto:
#   - Genera tráfico detectable
#   - Puede activar bloqueos / CAPTCHA / fail2ban
#   - Deja huellas en logs del servidor
# ---------------------------------------------------------

def dictionary_attack_online(
    server: FakeFTPServer,
    user: str,
    passwords: list[str],
) -> str | None:
    """Prueba cada contraseña del diccionario contra el servicio simulado."""
    print(f"\nObjetivo simulado: {server.host}")
    print(f"Usuario objetivo:   {user}")
    print(f"Candidatos:         {len(passwords)}\n")

    for index, password in enumerate(passwords, start=1):
        print(f"Intento {index}/{len(passwords)}:")
        if try_login(server, user, password):
            return password

    return None


# ---------------------------------------------------------
# 5. Función: main
# ---------------------------------------------------------

def main() -> None:
    print("=" * 60)
    print("SIMULACIÓN EDUCATIVA: ATAQUE DE DICCIONARIO ONLINE")
    print("Sin conexiones de red. Servidor FTP falso en memoria.")
    print("=" * 60)

    server = FakeFTPServer(
        host=DEMO_HOST,
        valid_user=DEMO_USER,
        valid_password=CORRECT_PASSWORD,
    )

    found = dictionary_attack_online(server, DEMO_USER, PASSWORD_DICTIONARY)

    print("\n" + "=" * 60)
    print("ANÁLISIS PARA EL ESTUDIANTE")
    print("=" * 60)
    if found:
        print(f"Contraseña encontrada en la demo: '{found}'")
    else:
        print("Ninguna contraseña del diccionario coincidió.")

    print()
    print("Qué hace un ataque ONLINE real:")
    print("  - Se conecta al servicio (FTP/SSH/web) en cada intento.")
    print("  - Depende de la red y de las defensas del servidor.")
    print("  - Es lento y ruidoso (fácil de detectar en logs).")
    print()
    print("Por qué esta demo es segura:")
    print("  - No usa ftplib.FTP ni sockets.")
    print("  - No resuelve hosts ni sale a Internet.")
    print("  - Credenciales y servidor son ficticios.")
    print()
    print("Defensas recomendadas (para el reporte):")
    print("  - Contraseñas fuertes y únicas / MFA.")
    print("  - Bloqueo tras N intentos fallidos.")
    print("  - VPN / restringir acceso por IP.")
    print("  - Monitoreo de logs de autenticación.")
    print("=" * 60)
    print("\nDemostración finalizada.")


# ---------------------------------------------------------
# 6. Punto de entrada
# ---------------------------------------------------------
# Ejecutar:
#   python diccionario_online.py
# ---------------------------------------------------------

if __name__ == "__main__":
    main()
