"""
Sniffer básico con Scapy (CY-302 Clase 11)

Captura tráfico TCP (HTTP puerto 80 por defecto) y muestra paquetes
cuyo payload menciona 'user' o 'pass' (credenciales en texto plano).

Ética: use solo en localhost o red de laboratorio autorizada.
En Windows: terminal como Administrador + Npcap.

Uso:
    python sniffer_basico.py
    python sniffer_basico.py --filtro "tcp port 21 or tcp port 80"
"""

from __future__ import annotations

import argparse
import sys

try:
    # Evitamos "from scapy.all import *" (importa demasiados nombres)
    from scapy.all import IP, TCP, Raw, sniff
except ImportError:
    print("[ERROR] Scapy no está instalado. Ejecute: pip install scapy")
    sys.exit(1)


def packet_callback(packet) -> None:
    """
    Versión corregida del ejemplo de la diapositiva:

        if packet[TCP].payload:
            payload = str(packet[TCP].payload)
            if 'user' in payload.lower() or 'pass' in payload.lower():
                ...

    Problemas del original:
      - packet[TCP] / packet[IP] lanzan excepción si la capa no existe
      - str(TCP.payload) a veces imprime el objeto Raw, no el texto útil
    """
    # Comprobar capas antes de indexar (evita IndexError / excepciones de Scapy)
    if not packet.haslayer(IP) or not packet.haslayer(TCP):
        return

    # Preferir la capa Raw (datos de aplicación). Si no hay, no hay payload útil.
    if packet.haslayer(Raw):
        try:
            payload = packet[Raw].load.decode("utf-8", errors="replace")
        except Exception:
            payload = str(packet[Raw].load)
    elif packet[TCP].payload:
        payload = str(packet[TCP].payload)
    else:
        return

    if "user" not in payload.lower() and "pass" not in payload.lower():
        return

    print(f"[{packet[IP].src}] -> [{packet[IP].dst}]")
    print(payload)
    print("-" * 50)


def main() -> None:
    parser = argparse.ArgumentParser(description="Sniffer básico con Scapy")
    parser.add_argument(
        "--filtro",
        default="tcp port 80",
        help='Filtro BPF (default: "tcp port 80", como en la diapositiva)',
    )
    parser.add_argument(
        "--iface",
        default=None,
        help="Interfaz de red (opcional). Ej: Ethernet, Wi-Fi, eth0",
    )
    parser.add_argument(
        "--contar",
        type=int,
        default=0,
        help="Detener tras N paquetes (0 = hasta Ctrl+C)",
    )
    args = parser.parse_args()

    print("=== Sniffer básico (Scapy) ===")
    print(f"Filtro : {args.filtro}")
    print(f"Iface  : {args.iface or '(default)'}")
    print("Ctrl+C para detener.\n")

    try:
        # sniff: captura paquetes
        #   filter -> expresión BPF (como tcpdump)
        #   prn    -> callback por cada paquete
        #   store=0 -> no acumular en memoria
        sniff(
            filter=args.filtro,
            prn=packet_callback,
            store=0,
            iface=args.iface,
            count=args.contar if args.contar > 0 else 0,
        )
    except PermissionError:
        print(
            "\n[ERROR] Se necesitan privilegios de administrador/root.\n"
            "En Windows: ejecute como Administrador e instale Npcap."
        )
        sys.exit(1)
    except OSError as error:
        print(f"\n[ERROR] No se pudo iniciar la captura: {error}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nCaptura detenida.")


if __name__ == "__main__":
    main()
