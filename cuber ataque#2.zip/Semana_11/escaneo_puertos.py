"""
Escaneo de puertos SYN con Scapy (CY-302 Clase 11)

Envía TCP SYN a cada puerto. Si responde SYN+ACK (SA), el puerto está abierto.

Ética: escanee solo hosts de laboratorio propios/autorizados.
En Windows: terminal como Administrador + Npcap.

Uso:
    python escaneo_puertos.py
    python escaneo_puertos.py --host 127.0.0.1 --puertos 20-25,80,443
"""

from __future__ import annotations

import argparse
import sys
from typing import Iterable, List

try:
    from scapy.all import IP, TCP, sr1, RandShort, send
except ImportError:
    print("[ERROR] Scapy no está instalado. Ejecute: pip install scapy")
    sys.exit(1)


def _flags_es_syn_ack(flags) -> bool:
    """
    En Scapy, flags puede ser int, FlagValue o str según versión.
    SYN+ACK = 0x12 (bit S + bit A). La comparación == "SA" del ejemplo
    de la diapositiva NO siempre funciona.
    """
    try:
        valor = int(flags)
        return valor == 0x12
    except (TypeError, ValueError):
        texto = str(flags)
        return texto in ("SA", "AS") or ("S" in texto and "A" in texto)


def parsear_puertos(texto: str) -> List[int]:
    """Convierte '20-25,80,443' en lista de enteros."""
    puertos: List[int] = []
    for parte in texto.split(","):
        parte = parte.strip()
        if not parte:
            continue
        if "-" in parte:
            a, b = parte.split("-", 1)
            puertos.extend(range(int(a), int(b) + 1))
        else:
            puertos.append(int(parte))
    return sorted(set(puertos))


def port_scan(host: str, port_range: Iterable[int], timeout: float = 1.0) -> None:
    """
    SYN scan (mismo enfoque que la diapositiva):

        packet = IP(dst=host)/TCP(sport=..., dport=..., flags="S")
        response = sr1(packet, timeout=..., verbose=0)
        si flags == SYN+ACK → puerto abierto
    """
    print(f"\nEscaneando {host} ...")
    abiertos = []

    for dst_port in port_range:
        src_port = RandShort()
        packet = IP(dst=host) / TCP(sport=src_port, dport=dst_port, flags="S")

        try:
            response = sr1(packet, timeout=timeout, verbose=0)
        except PermissionError:
            print(
                "\n[ERROR] Se necesitan privilegios de administrador/root.\n"
                "En Windows: ejecute como Administrador e instale Npcap."
            )
            return
        except OSError as error:
            print(f"\n[ERROR] Falló el envío: {error}")
            return

        if response is None:
            # Filtrado o sin respuesta (no imprimimos cada uno para no saturar)
            continue

        if not response.haslayer(TCP):
            continue

        if _flags_es_syn_ack(response[TCP].flags):
            print(f"Port {dst_port} is open")
            abiertos.append(dst_port)
            # Cerrar el half-open: enviar RST (buena práctica)
            rst = IP(dst=host) / TCP(sport=src_port, dport=dst_port, flags="R")
            send(rst, verbose=0)

    print("\nResumen puertos abiertos:", abiertos or "(ninguno detectado)")


def main() -> None:
    parser = argparse.ArgumentParser(description="Escaneo SYN de puertos con Scapy")
    parser.add_argument(
        "--host",
        default="192.168.100.117",
        help="Host de laboratorio (default: 127.0.0.1; NO use IPs ajenas)",
    )
    parser.add_argument(
        "--puertos",
        default="20-25,80,443,5132",
        help="Puertos o rangos (default: 20-25,80,443). Evite 1-1024 en demos.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=1.0,
        help="Timeout por puerto en segundos (default: 1.0)",
    )
    args = parser.parse_args()

    print("=== Escaneo de puertos SYN (Scapy) ===")
    print("Use solo hosts autorizados / de laboratorio.\n")

    try:
        puertos = parsear_puertos(args.puertos)
    except ValueError:
        print("[ERROR] Formato de --puertos inválido. Ej: 20-25,80,443")
        sys.exit(1)

    if not puertos:
        print("[ERROR] No hay puertos que escanear.")
        sys.exit(1)

    port_scan(args.host, puertos, timeout=args.timeout)


if __name__ == "__main__":
    main()
