# Importamos las funciones y clases principales de Scapy
# IMPORTANTE: deben venir de scapy.all (no de "import scapy")
# ARP -> para construir paquetes ARP (preguntar "¿quién tiene esta IP?")
# Ether -> para construir tramas Ethernet (capa 2)
# srp -> para ENVIAR y RECIBIR paquetes a nivel de capa 2
try:
    from scapy.all import ARP, Ether, srp
except ImportError:
    print("[ERROR] Scapy no está instalado. Ejecute: pip install scapy")
    raise SystemExit(1)


def escanear_red(red_objetivo: str):
    """
    Escanea la red indicada usando ARP y devuelve
    una lista de diccionarios con IP y MAC de los dispositivos
    encontrados.
    Parámetro:
    red_objetivo: cadena con el rango de red, por ejemplo
    "192.168.1.0/24"
    """
    # 1) Creamos el paquete ARP.
    # pdst = "protocol destination" -> a qué IPs vamos a preguntar.
    # Aquí se puede usar un rango, como "192.168.1.0/24".
    arp = ARP(pdst=red_objetivo)

    # 2) Creamos la trama Ethernet de broadcast.
    # dst = "destination MAC". La MAC ff:ff:ff:ff:ff:ff significa:
    # "enviar a todos los dispositivos de la red local".
    ether = Ether(dst="ff:ff:ff:ff:ff:ff")

    # 3) Combinamos las capas con el operador "/".
    # Primero va la capa 2 (Ethernet) y encima la capa ARP.
    # Esto representa el paquete completo que se enviará por la red.
    packet = ether / arp

    # 4) Enviamos el paquete y esperamos respuestas.
    # srp = send and receive packets at layer 2 (Ethernet).
    # timeout=2 -> espera máximo 2 segundos por respuestas.
    # verbose=0 -> no muestra información adicional en pantalla.
    # srp devuelve dos listas: (respuesta_ok, respuesta_no_recibida).
    try:
        respuestas, _ = srp(packet, timeout=2, verbose=0)
    except PermissionError:
        print(
            "\n[ERROR] Se necesitan privilegios de administrador/root "
            "para enviar paquetes ARP.\n"
            "En Windows: ejecute la terminal como Administrador "
            "e instale Npcap (https://npcap.com/)."
        )
        return []
    except OSError as error:
        print(f"\n[ERROR] No se pudo enviar el escaneo ARP: {error}")
        return []

    # 5) Recorremos las respuestas y extraemos IP y MAC de cada host.
    hosts = []
    for _enviado, recibido in respuestas:
        # recibido.psrc = IP origen del paquete de respuesta (la IP del host).
        # recibido.hwsrc = MAC origen del paquete de respuesta (la MAC del host).
        host_info = {
            "ip": recibido.psrc,
            "mac": recibido.hwsrc,
        }
        hosts.append(host_info)

    # Ordenamos por IP para facilitar la lectura en clase.
    hosts.sort(key=lambda h: tuple(int(octet) for octet in h["ip"].split(".")))

    # Devolvemos la lista de hosts encontrados.
    return hosts


def imprimir_resultados(hosts):
    """
    Imprime en forma de tabla la lista de hosts encontrados.

    Parámetro:
        hosts: lista de diccionarios con claves "ip" y "mac".
    """

    # Si la lista está vacía, no se encontró ningún dispositivo.
    if not hosts:
        print("\nNo se encontraron dispositivos en la red indicada.")
        return

    # Encabezado de la tabla
    print("\nDispositivos encontrados:")
    # ljust(18) alinea el texto a la izquierda ocupando 18 caracteres.
    print("IP".ljust(18), "MAC")
    print("-" * 35)

    # Recorremos la lista de hosts e imprimimos IP y MAC de cada uno.
    for host in hosts:
        ip = host["ip"]
        mac = host["mac"]
        print(ip.ljust(18), mac)


def main():
    """
    Función principal del programa.
    Pide al usuario la red a escanear, realiza el escaneo e imprime
    resultados.
    """

    print("=== Scanner ARP sencillo con Scapy ===")
    print("Use solo redes de laboratorio propias/autorizadas.\n")
    # Pedimos al usuario la red a escanear.
    # Ejemplos:
    # 192.168.1.0/24
    # 10.0.0.0/24
    red = input("Ingrese la red a escanear (ej: 192.168.1.0/24): ").strip()

    # Si el usuario no escribe nada, salimos.
    if not red:
        print("No ingresó una red válida. Saliendo...")
        return

    # Validación mínima del formato CIDR (ej. 192.168.1.0/24).
    if "/" not in red or red.count(".") != 3:
        print(
            "Formato inválido. Use notación CIDR, por ejemplo: 192.168.1.0/24"
        )
        return

    # Llamamos a la función que hace el escaneo con ARP.
    print(f"\nEscaneando {red} ... (puede tardar unos segundos)")
    hosts_encontrados = escanear_red(red)

    # Imprimimos los resultados en pantalla en forma de tabla
    imprimir_resultados(hosts_encontrados)


# Este bloque se ejecuta solo si el archivo se corre directamente
# (por ejemplo: python ejemplo_clase11.py)
if __name__ == "__main__":
    main()
