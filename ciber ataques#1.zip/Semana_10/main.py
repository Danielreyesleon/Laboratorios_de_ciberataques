# ---------------------------------------------------------
# Script: detector de contraseñas débiles usando hashes SHA-256
# Contexto:
# Tenemos:
# - Un archivo con contraseñas comunes: common_passwords.txt
# - Un archivo con hashes SHA-256: password_hashes.txt
# Objetivo:
# Verificar si alguna contraseña común aparece (en forma de hash)
# dentro de la lista de hashes, lo que indica contraseñas débiles.
# ---------------------------------------------------------

import hashlib # Librería estándar de Python para calcular hashes (ej:SHA-256)

# ---------------------------------------------------------
# 1. Cargar la lista de contraseñas comunes desde el archivo
# ---------------------------------------------------------
# El archivo 'common_passwords.txt' debe estar en la misma carpeta
# que este script. Cada línea del archivo contiene una contraseña.
# Ejemplo de contenido:
# 123456
# password
# admin
# welcome
# abc123
# ---------------------------------------------------------

with open('common_passwords.txt', 'r', encoding='utf-8') as file:
    # Recorremos cada línea del archivo, eliminamos saltos de línea
    # con strip() y construimos una lista de contraseñas comunes.
    common_passwords = [line.strip() for line in file]

print("Contraseñas comunes cargadas:")
print(common_passwords)
print("-" * 50)

# ---------------------------------------------------------
# 2. Cargar la lista de hashes SHA-256 desde el archivo
# ---------------------------------------------------------
# El archivo 'password_hashes.txt' también debe estar en la misma
# carpeta que este script. Cada línea contiene un hash SHA-256 en
# formato hexadecimal (64 caracteres).
#
# Ejemplo sencillo de contenido:
# 5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8
#
# Ese hash corresponde a la contraseña "password".
# ---------------------------------------------------------

with open('password_hashes.txt', 'r', encoding='utf-8') as file:
    # De forma similar, leemos cada línea del archivo,
    # eliminamos saltos de línea y construimos una lista de hashes.
    password_hashes = [line.strip() for line in file]

print("Hashes cargados:")
print(password_hashes)
print("-" * 50)

# ---------------------------------------------------------
# 3. Comparar cada contraseña común contra la lista de hashes
# ---------------------------------------------------------
# La idea:
# - Tomar cada contraseña de common_passwords.
# - Calcular su hash SHA-256 con hashlib.
# - Convertir el hash a cadena hexadecimal con hexdigest().
# - Preguntar: ¿ese hash calculado está dentro de password_hashes?
# - Si sí, entonces esa contraseña común la está usando alguien
# (porque su hash apareció en la base de datos).
# ---------------------------------------------------------

# Variable para llevar la cuenta de cuántas contraseñas débiles encontramos
weak_count = 0

# Recorremos cada contraseña común de la lista
for password in common_passwords:
    # 1) Codificamos la contraseña a bytes con encode()
    # (hashlib trabaja con bytes, no con str directamente)
    password_bytes = password.encode()

    # 2) Calculamos el hash SHA-256 de esa contraseña
    # hashlib.sha256(...) devuelve un objeto hash
    hash_object = hashlib.sha256(password_bytes)

    # 3) Convertimos el objeto hash a su representación hexadecimal
    # (cadena de 64 caracteres hexadecimales)
    password_hash = hash_object.hexdigest()

    # 4) Verificamos si este hash calculado está dentro de la lista de hashes
    if password_hash in password_hashes:
        print(f"⚠️ Se ha encontrado una contraseña débil: '{password}'")
        weak_count += 1

# ---------------------------------------------------------
# 4. Reporte final
# ---------------------------------------------------------
# Si weak_count es 0, entonces ninguna de las contraseñas comunes
# apareció en la lista de hashes.
# Si es > 0, mostramos cuántas encontramos.
# ---------------------------------------------------------

if weak_count == 0:
    print("✅ No se encontraron contraseñas débiles en la lista de hashes.")
else:
    print("-" * 50)
    print(f"Total de contraseñas débiles encontradas: {weak_count}")