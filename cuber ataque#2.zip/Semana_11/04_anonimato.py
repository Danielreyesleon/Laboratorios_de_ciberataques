"""
================================================================================
LABORATORIO 04 — Anonimato y privacidad en Python
Curso: CY-302 Programación Avanzada | Clase 11
================================================================================

OBJETIVO DIDÁCTICO
------------------
Aplicar las ideas de la diapositiva "Anonimato en Python":
  1) Proxies HTTP/HTTPS con la biblioteca requests
  2) (Opcional) Tor vía SOCKS5
  3) Reducir huella: User-Agent, cabeceras, sesiones
  4) Buenas prácticas: no filtrar datos personales, borrado seguro de rastros

Por defecto este laboratorio NO depende de un proxy real: usa un modo
demostración que explica el flujo y valida la forma de las peticiones.
Si el estudiante tiene un proxy de laboratorio, puede activarlo con flags.

Ética
-----
El anonimato protege la privacidad; no justifica actividades ilícitas.
Tor/proxies mal configurados pueden filtrar la IP real (DNS leaks, etc.).

USO
---
    python 04_anonimato.py                      # explicación + demo local
    python 04_anonimato.py --verificar-ip       # consulta IP pública (sin proxy)
    python 04_anonimato.py --proxy http://127.0.0.1:8080 --verificar-ip
    python 04_anonimato.py --tor --verificar-ip # requiere Tor en 9050
================================================================================
"""

from __future__ import annotations

import argparse
import hashlib
import os
import sys
import tempfile
from typing import Any, Dict, Optional

try:
    import requests
except ImportError:
    print("[ERROR] requests no está instalado. Ejecute: pip install requests")
    sys.exit(1)


URL_IP = "https://api.ipify.org?format=json"
URL_EJEMPLO = "https://httpbin.org/headers"


# =============================================================================
# TEORÍA
# =============================================================================
def explicar_anonimato() -> None:
    print(
        """
╔══════════════════════════════════════════════════════════════════════════════╗
║  ANONIMATO EN PYTHON — IDEAS DE LA CLASE                                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Anonimato = ocultar identidad al comunicarse en red.                        ║
║                                                                              ║
║  Python puede ayudar mediante:                                               ║
║    • Proxies → el servidor ve la IP del proxy, no la suya                    ║
║    • Cifrado (HTTPS/TLS, VPN) → protege el contenido                         ║
║    • Minimización de datos → no enviar PII innecesaria                       ║
║    • Borrado / no persistencia de rastros (logs, temporales)                 ║
║                                                                              ║
║  Ejemplo de la diapositiva:                                                  ║
║      proxy = {"http": "http://10.10.1.10:3128",                              ║
║               "https": "http://10.10.1.10:1080"}                             ║
║      requests.get("http://example.com", proxies=proxy)                       ║
║                                                                              ║
║  Limitaciones (para discutir en clase):                                      ║
║    • El proxy puede ver su tráfico si no usa HTTPS de extremo a extremo      ║
║    • Cookies, logins y huellas del navegador siguen identificándolo          ║
║    • DNS mal configurado puede filtrar la IP real                            ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    )


# =============================================================================
# CONSTRUCCIÓN DE PROXIES (como en la PPT + variantes)
# =============================================================================
def construir_proxies(
    proxy_url: Optional[str] = None,
    usar_tor: bool = False,
) -> Dict[str, str]:
    """
    Devuelve el diccionario `proxies` que entiende requests.

    - proxy_url: p.ej. http://10.10.1.10:3128  (diapositiva)
    - usar_tor : SOCKS5 en 127.0.0.1:9050 (Tor Browser / tor service)
                 Requiere: pip install requests[socks]  PySocks
    """
    if usar_tor:
        # Puerto 9050 = demonio Tor; 9150 = Tor Browser
        tor = "socks5h://127.0.0.1:9050"
        print(f"[proxy] Usando Tor vía {tor}")
        return {"http": tor, "https": tor}

    if proxy_url:
        print(f"[proxy] Usando proxy de laboratorio: {proxy_url}")
        # Misma idea que la diapositiva: un dict http/https
        return {"http": proxy_url, "https": proxy_url}

    # Valores de ejemplo de la PPT (NO se usan para conectar de verdad aquí)
    ejemplo = {
        "http": "http://10.10.1.10:3128",
        "https": "http://10.10.1.10:1080",
    }
    print("[proxy] Diccionario de ejemplo (diapositiva), sin conexión forzada:")
    print(f"        {ejemplo}")
    return ejemplo


def cabeceras_privadas() -> Dict[str, str]:
    """
    Reduce un poco la huella respecto al User-Agent por defecto de requests
    (que delata 'python-requests/x.y').
    """
    return {
        "User-Agent": (
            "Mozilla/5.0 (compatible; CY302-Lab/1.0; +laboratorio-aula)"
        ),
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "es-CR,es;q=0.9",
        "DNT": "1",
    }


# =============================================================================
# DEMOSTRACIONES
# =============================================================================
def demo_codigo_diapositiva() -> None:
    """Muestra literalmente el patrón de la clase, sin ejecutarlo a esa IP."""
    print("\n--- Ejemplo de la diapositiva (patrón) ---\n")
    print(
        """
import requests

proxy = {
    "http":  "http://10.10.1.10:3128",
    "https": "http://10.10.1.10:1080",
}
# requests.get("http://example.com", proxies=proxy)
"""
    )
    print(
        "En el aula, sustituya 10.10.1.10 por el proxy del laboratorio "
        "y use --proxy / --verificar-ip."
    )


def verificar_ip_publica(proxies: Optional[Dict[str, str]] = None) -> None:
    """
    Consulta un servicio que devuelve la IP vista desde Internet.
    Permite comparar: sin proxy vs con proxy/Tor.
    """
    print("\n--- Verificar IP pública vista por el servidor ---")
    try:
        r = requests.get(
            URL_IP,
            proxies=proxies,
            headers=cabeceras_privadas(),
            timeout=15,
        )
        r.raise_for_status()
        data = r.json()
        print(f"  IP observada: {data.get('ip')}")
        print(f"  status={r.status_code}")
    except requests.exceptions.ProxyError as e:
        print(f"  [ProxyError] No se pudo usar el proxy: {e}")
        print("  ¿Está el proxy/Tor encendido? ¿Puerto correcto?")
    except requests.RequestException as e:
        print(f"  [Error de red] {e}")


def mostrar_cabeceras_enviadas(proxies: Optional[Dict[str, str]] = None) -> None:
    """Usa httpbin para ver qué cabeceras recibe el servidor."""
    print("\n--- Cabeceras que recibe el servidor (httpbin) ---")
    try:
        r = requests.get(
            URL_EJEMPLO,
            proxies=proxies,
            headers=cabeceras_privadas(),
            timeout=15,
        )
        r.raise_for_status()
        headers = r.json().get("headers", {})
        for k, v in headers.items():
            print(f"  {k}: {v}")
    except requests.RequestException as e:
        print(f"  [Error] {e}")


def demo_sesion_aislada() -> None:
    """
    requests.Session() reutiliza cookies. Para privacidad, a veces conviene
    una sesión limpia por operación (o no persistir cookies a disco).
    """
    print("\n--- Sesión aislada (sin filtrar cookies entre sitios) ---")
    with requests.Session() as s:
        s.headers.update(cabeceras_privadas())
        print(f"  Cabeceras de sesión: User-Agent={s.headers.get('User-Agent')}")
        print("  Al salir del `with`, la sesión se cierra y no deja cookies en disco.")


def borrado_seguro_demo() -> None:
    """
    Ilustra la idea de 'eliminar rastros' del enunciado de práctica:
    no guardar secretos en claro; sobrescribir archivos temporales.
    (Demostración educativa; no es un wipe forense completo.)
    """
    print("\n--- Eliminación de rastros (demo educativa) ---")
    secreto = "token-de-laboratorio-NO-COMMITEAR"
    fd, ruta = tempfile.mkstemp(prefix="cy302_", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(secreto)

        print(f"  Temporal creado: {ruta}")
        huella = hashlib.sha256(secreto.encode()).hexdigest()[:16]
        print(f"  Huella SHA-256 (16 hex): {huella}  ← guarde hashes, no secretos")

        # Sobrescritura simple antes de borrar
        size = os.path.getsize(ruta)
        with open(ruta, "wb") as f:
            f.write(b"\x00" * size)
        print("  Archivo sobrescrito con ceros.")
    finally:
        if os.path.exists(ruta):
            os.remove(ruta)
            print("  Archivo eliminado. Preferible: no escribir secretos a disco.")


def checklist_privacidad() -> None:
    print(
        """
╔══════════════════════════════════════════════════════════════════════════════╗
║  CHECKLIST PARA EL ESTUDIANTE (práctica de la clase)                         ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  [ ] ¿Uso HTTPS siempre que sea posible?                                     ║
║  [ ] ¿El proxy/Tor está bajo mi control o es de confianza del laboratorio?   ║
║  [ ] ¿Evito imprimir contraseñas/tokens en logs?                             ║
║  [ ] ¿No subo .env, cookies ni capturas con datos personales a Git?          ║
║  [ ] ¿Las demos de sniffer/ARP solo corren en la red del aula?               ║
║  [ ] ¿Documenté limitaciones (DNS leak, fingerprinting, logs del proxy)?     ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    )


# =============================================================================
# CLI
# =============================================================================
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Laboratorio de anonimato en Python (CY-302 Clase 11)"
    )
    parser.add_argument(
        "--proxy",
        metavar="URL",
        help="Proxy HTTP del laboratorio, ej. http://10.10.1.10:3128",
    )
    parser.add_argument(
        "--tor",
        action="store_true",
        help="Usar Tor (SOCKS5 en 127.0.0.1:9050)",
    )
    parser.add_argument(
        "--verificar-ip",
        action="store_true",
        help="Consultar la IP pública (con o sin proxy)",
    )
    parser.add_argument(
        "--cabeceras",
        action="store_true",
        help="Mostrar cabeceras vistas por httpbin.org",
    )
    args = parser.parse_args()

    explicar_anonimato()
    demo_codigo_diapositiva()
    demo_sesion_aislada()
    borrado_seguro_demo()
    checklist_privacidad()

    # ¿Hay que hacer peticiones reales?
    if not (args.verificar_ip or args.cabeceras or args.proxy or args.tor):
        print(
            "Tip: compare su IP sin/con proxy:\n"
            "  python 04_anonimato.py --verificar-ip\n"
            "  python 04_anonimato.py --proxy http://IP:PUERTO --verificar-ip\n"
            "  python 04_anonimato.py --tor --verificar-ip\n"
        )
        return

    proxies: Optional[Dict[str, str]]
    if args.tor or args.proxy:
        proxies = construir_proxies(args.proxy, usar_tor=args.tor)
    else:
        proxies = None
        print("[red] Sin proxy: el servidor verá su IP real.")

    if args.verificar_ip:
        verificar_ip_publica(proxies)
    if args.cabeceras:
        mostrar_cabeceras_enviadas(proxies)


if __name__ == "__main__":
    main()
