"""
================================================================================
LABORATORIO 03 — Sniffer de red con Scapy (FTP / HTTP en claro)
Curso: CY-302 Programación Avanzada | Clase 11
================================================================================

OBJETIVO DIDÁCTICO
------------------
Explicar qué es un sniffer (analizador de protocolos), cómo Scapy captura
paquetes con sniff(), cómo se filtra por puerto y cómo se detectan credenciales
enviadas en texto plano (FTP / HTTP), tal como indica la diapositiva.

NOTA IMPORTANTE SOBRE HTTPS
---------------------------
La diapositiva menciona "FTP y https". HTTPS cifra el contenido con TLS:
un sniffer ve IPs y puertos, pero NO puede leer usuario/contraseña del payload
sin romper el cifrado (lo cual NO hacemos aquí). En este laboratorio:

  • FTP  (puerto 21)  → credenciales en claro  → se demuestran
  • HTTP (puerto 80)  → formularios/Basic Auth → se demuestran
  • HTTPS(puerto 443) → solo metadatos         → se explica por qué NO se leen

Ética
-----
Capturar tráfico ajeno sin autorización es ilegal. Use solo en localhost o
en la red de laboratorio del aula, con tráfico generado por usted.

USO
---
    # Demo con paquetes sintéticos (no necesita privilegios ni red):
    python 03_sniffer.py --demo

    # Captura real (requiere admin/Npcap; Ctrl+C para detener):
    python 03_sniffer.py --iface "Ethernet" --filtro "tcp port 21 or tcp port 80"
    python 03_sniffer.py --contar 20
================================================================================
"""

from __future__ import annotations

import argparse
import re
import sys
from typing import Optional


try:
    from scapy.all import (  # type: ignore
        IP,
        TCP,
        Raw,
        Ether,
        sniff,
        conf,
    )
except ImportError:
    print("[ERROR] Scapy no está instalado. Ejecute: pip install scapy")
    sys.exit(1)

conf.verb = 0


# Palabras clave típicas de login en protocolos en claro (diapositiva)
PATRON_CREDENCIAL = re.compile(
    r"(?i)\b(USER|PASS|username|password|passwd|login|Authorization)\b"
)


# =============================================================================
# TEORÍA
# =============================================================================
def explicar_sniffer() -> None:
    print(
        """
╔══════════════════════════════════════════════════════════════════════════════╗
║  ¿QUÉ ES UN SNIFFER?                                                         ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Programa que intercepta, analiza y registra tráfico de red.                 ║
║  También se llama "analizador de protocolos".                                ║
║                                                                              ║
║  Usos legítimos: diagnóstico, seguridad, rendimiento, depuración.            ║
║                                                                              ║
║  Con Scapy:                                                                  ║
║      sniff(filter="tcp port 80", prn=callback, store=0)                      ║
║                                                                              ║
║        filter → expresión BPF (como en tcpdump/Wireshark)                    ║
║        prn    → función llamada por cada paquete                             ║
║        store  → 0 = no guardar en memoria (mejor para demos largas)          ║
║                                                                              ║
║  Capas que veremos:                                                          ║
║      Ether / IP / TCP / Raw(payload)                                         ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    )


# =============================================================================
# CALLBACK — corazón del sniffer de la diapositiva
# =============================================================================
def extraer_payload(packet) -> Optional[str]:
    """Obtiene el contenido de aplicación si existe (capa Raw o payload TCP)."""
    if packet.haslayer(Raw):
        try:
            return packet[Raw].load.decode("utf-8", errors="replace")
        except Exception:
            return str(packet[Raw].load)
    # Fallback como en la diapositiva: packet[TCP].payload
    if packet.haslayer(TCP) and packet[TCP].payload:
        return str(packet[TCP].payload)
    return None


def packet_callback(packet) -> None:
    """
    Versión didáctica del callback de la diapositiva:

        if packet[TCP].payload:
            payload = str(packet[TCP].payload)
            if 'user' in payload.lower() or 'pass' in payload.lower():
                print(...)

    Mejoras para clase:
      - comprueba capas con haslayer (evita excepciones)
      - muestra IP origen/destino y puertos
      - resalta líneas USER/PASS de FTP
    """
    if not packet.haslayer(TCP) or not packet.haslayer(IP):
        return

    payload = extraer_payload(packet)
    if not payload:
        return

    if not PATRON_CREDENCIAL.search(payload):
        return

    src = packet[IP].src
    dst = packet[IP].dst
    sport = packet[TCP].sport
    dport = packet[TCP].dport

    print("=" * 70)
    print(f"[{src}:{sport}] → [{dst}:{dport}]")
    print("-" * 70)

    # Resaltar líneas interesantes (FTP USER/PASS, headers HTTP)
    for linea in payload.replace("\r", "").split("\n"):
        if PATRON_CREDENCIAL.search(linea):
            print(f"  ★ {linea[:200]}")
        elif linea.strip():
            # Mostrar un poco de contexto sin volcar todo el HTML
            if len(linea) < 120:
                print(f"    {linea}")

    print("=" * 70)


def callback_https_metadatos(packet) -> None:
    """
    Para tráfico al puerto 443: solo metadatos.
    Demuestra que el payload NO es legible (cifrado TLS).
    """
    if not (packet.haslayer(IP) and packet.haslayer(TCP)):
        return
    if packet[TCP].dport != 443 and packet[TCP].sport != 443:
        return

    tam = len(packet[Raw].load) if packet.haslayer(Raw) else 0
    print(
        f"[HTTPS metadatos] {packet[IP].src}:{packet[TCP].sport} → "
        f"{packet[IP].dst}:{packet[TCP].dport}  bytes_payload={tam}  "
        "(contenido CIFRADO — no se leen contraseñas)"
    )


# =============================================================================
# DEMO SINTÉTICA — sin necesidad de captura real
# =============================================================================
def _paquete_ftp_falso(user: str = "alumno", password: str = "SecretoLab123"):
    """Construye paquetes TCP/Raw que simulan un login FTP en claro."""
    login = (
        Ether()
        / IP(src="10.0.0.20", dst="10.0.0.5")
        / TCP(sport=45000, dport=21)
        / Raw(load=f"USER {user}\r\n")
    )
    passwd = (
        Ether()
        / IP(src="10.0.0.20", dst="10.0.0.5")
        / TCP(sport=45000, dport=21)
        / Raw(load=f"PASS {password}\r\n")
    )
    return login, passwd


def _paquete_http_falso():
    """Simula un POST HTTP (sin TLS) con password en el body."""
    body = "username=admin&password=admin123"
    raw = (
        "POST /login HTTP/1.1\r\n"
        "Host: lab.local\r\n"
        "Content-Type: application/x-www-form-urlencoded\r\n"
        f"Content-Length: {len(body)}\r\n"
        "\r\n"
        f"{body}"
    )
    return (
        Ether()
        / IP(src="10.0.0.30", dst="10.0.0.5")
        / TCP(sport=51000, dport=80)
        / Raw(load=raw)
    )


def demo_sintetica() -> None:
    """
    Recorre el callback con paquetes inventados.
    Ideal para explicar en clase SIN activar el sniffer real.
    """
    print("\n--- DEMO SINTÉTICA (paquetes construidos en memoria) ---\n")
    print("1) Login FTP en texto plano:")
    for pkt in _paquete_ftp_falso():
        packet_callback(pkt)

    print("\n2) Formulario HTTP (puerto 80) en texto plano:")
    packet_callback(_paquete_http_falso())

    print(
        """
3) ¿Y HTTPS?
   El payload iría cifrado. El sniffer solo vería algo como:
   [HTTPS metadatos] 10.0.0.30:52000 → 10.0.0.5:443  bytes_payload=517
   Conclusión didáctica: use siempre HTTPS/TLS; el sniffer deja de ser útil
   para robar contraseñas cuando el canal está cifrado.
"""
    )


# =============================================================================
# CAPTURA REAL
# =============================================================================
def iniciar_sniffer(
    iface: Optional[str],
    filtro: str,
    contar: int,
    incluir_https: bool,
) -> None:
    print(f"\n--- CAPTURA REAL ---")
    print(f"  Interfaz : {iface or '(default del sistema)'}")
    print(f"  Filtro   : {filtro}")
    print(f"  Límite   : {contar if contar > 0 else 'hasta Ctrl+C'}")
    print("  Esperando paquetes...\n")

    def _prn(pkt):
        packet_callback(pkt)
        if incluir_https:
            callback_https_metadatos(pkt)

    sniff(
        iface=iface,
        filter=filtro,
        prn=_prn,
        store=0,
        count=contar if contar > 0 else 0,
    )


# =============================================================================
# CLI
# =============================================================================
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Laboratorio didáctico de sniffer con Scapy (CY-302)"
    )
    parser.add_argument(
        "--demo",
        action="store_true",
        help="Ejecuta la demo sintética sin capturar de la red",
    )
    parser.add_argument(
        "--iface",
        default=None,
        help='Interfaz de red (ej. "Ethernet", "Wi-Fi", "eth0")',
    )
    parser.add_argument(
        "--filtro",
        default="tcp port 21 or tcp port 80",
        help="Filtro BPF (default: FTP y HTTP en claro)",
    )
    parser.add_argument(
        "--contar",
        type=int,
        default=0,
        help="Detener tras N paquetes (0 = hasta Ctrl+C)",
    )
    parser.add_argument(
        "--https-meta",
        action="store_true",
        help="También muestra metadatos de tráfico al puerto 443",
    )
    args = parser.parse_args()

    explicar_sniffer()

    if args.demo or (args.iface is None and args.contar == 0 and not args.https_meta):
        # Por defecto, si no piden captura, mostramos la demo segura
        if not args.demo and args.iface is None:
            print(
                "[Modo seguro] No se indicó --iface. Ejecutando demo sintética.\n"
                "Para captura real: python 03_sniffer.py --iface <nombre> --contar 30\n"
            )
        demo_sintetica()
        return

    print(
        "\n⚠  Captura real: use solo tráfico propio / red de laboratorio.\n"
        "   En Windows ejecute la terminal como Administrador.\n"
    )
    iniciar_sniffer(args.iface, args.filtro, args.contar, args.https_meta)


if __name__ == "__main__":
    main()
